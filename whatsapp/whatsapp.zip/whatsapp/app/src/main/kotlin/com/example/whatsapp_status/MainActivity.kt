package com.example.whatsapp_status

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
