import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:whatsapp_status/ui/videoScreen.dart';

import 'imageScreen.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({Key? key}) : super(key: key);
  final html =
       '<h3><b>How To Use?</b></h3><p>- Check the Desired Status/Story...</p><p>- Come Back to App, Click on any Image or Video to View...</p><p>- Click the Save Button...<br />The Image/Video is Instantly saved to your Galery :)</p><p>- You can also Use Multiple Saving. [to do]</p>';

  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2, // Number of tabs
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.teal,
          actions: [
            IconButton(
                onPressed: ()
                {
                  AdaptiveTheme.of(context).toggleThemeMode();
                }, icon: Icon(Icons.lightbulb_outline)),
            
            PopupMenuButton<String>(
              onSelected: choiceAction,
                itemBuilder: (BuildContext context)
            {
              return Constants.choices.map((String choice) {
                return PopupMenuItem<String>(
                  value: choice,
                  child: Text(choice),
                );
              }).toList();
            },
            )
          ],
          title: const Text('Save Status'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'IMAGES'),
              Tab(text: 'VIDEOS'),
            ],
          ),
        ),

        drawer: Drawer(
          child: ListView(
            // Important: Remove any padding from the ListView.
            padding: EdgeInsets.zero,
            children: [
              const UserAccountsDrawerHeader(
                decoration: BoxDecoration(color: Colors.white),
                accountName: Text(
                  "Save Status",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.teal,
                  ),
                ),
                currentAccountPicture: CircleAvatar(
                  radius: 80.0, // Adjust the size as needed
                  backgroundImage: AssetImage("images/saveStatus.png"),
                ),
                accountEmail: null,
              ),
              ListTile(
                leading: Icon(
                  Icons.movie,
                  color: Colors.teal,
                ),
                title: const Text('All Videos'),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(
                  Icons.language,
                  color: Colors.teal,
                ),
                title: const Text('Select Language'),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(
                  Icons.restart_alt,
                  color: Colors.teal,
                ),
                title: const Text('Restart Service'),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(
                  Icons.mark_unread_chat_alt_outlined,
                  color: Colors.teal,
                ),
                title: const Text('Status Notification'),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(
                  Icons.download,
                  color: Colors.teal,
                ),
                title: const Text('Auto Save Status'),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        ),

        body: const TabBarView(
          children: [
            ImageScreen(),
            VideoScreen(),
          ],
        ),
      ),
    );
  }

  void choiceAction(String choice)
  {
    if (choice == Constants.about) {
    } else if (choice == Constants.rate) {
    } else if (choice == Constants.share) {}
  }
}

class Constants
{
  static const String about = 'About App';
  static const String rate = 'Rate App';
  static const String share = 'Share with friends';

  static const List<String> choices = <String>[about, rate, share];
}
