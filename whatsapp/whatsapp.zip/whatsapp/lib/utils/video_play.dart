import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_isolate/flutter_isolate.dart';
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';
import 'video_controller.dart';
import 'package:permission_handler/permission_handler.dart';

class PlayStatus extends StatefulWidget {
  final String videoFile;
  const PlayStatus({
    Key? key,
    required this.videoFile,
  }) : super(key: key);
  @override
  _PlayStatusState createState() => _PlayStatusState();
}

class _PlayStatusState extends State<PlayStatus> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  void _onLoading(bool t, String str) {
    if (t) {
      showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return SimpleDialog(
              children: <Widget>[
                Center(
                  child: Container(
                      padding: const EdgeInsets.all(10.0),
                      child: const CircularProgressIndicator()),
                ),
              ],
            );
          });
    } else {
      Navigator.pop(context);
      showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: SimpleDialog(
                children: <Widget>[
                  Center(
                    child: Container(
                      padding: const EdgeInsets.all(15.0),
                      child: Column(
                        children: <Widget>[
                          const Text(
                            'Great, Saved in Gallary',
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.bold),
                          ),
                          const Padding(
                            padding: EdgeInsets.all(10.0),
                          ),
                          Text(str,
                              style: const TextStyle(
                                fontSize: 16.0,
                              )),
                          const Padding(
                            padding: EdgeInsets.all(10.0),
                          ),
                          const Text('FileManager > wa_status_saver',
                              style: TextStyle(
                                  fontSize: 16.0, color: Colors.teal)),
                          const Padding(
                            padding: EdgeInsets.all(10.0),
                          ),
                          MaterialButton(
                            child: const Text('Close'),
                            color: Colors.teal,
                            textColor: Colors.white,
                            onPressed: () => Navigator.pop(context),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: Colors.transparent,
        leading: IconButton(
          color: Colors.white,
          icon: const Icon(
            Icons.close,
            color: Colors.white,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: StatusVideo(
        videoPlayerController:
        VideoPlayerController.file(File(widget.videoFile)),

        looping: true,
        videoSrc: widget.videoFile,
      ),
      // ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.teal,
        child: const Icon(Icons.save),
        onPressed: _saveVideo,
      ),

    );
  }


  Future<void> _saveVideo() async
  {
    print("1");
    if (widget.videoFile != null) {
      print("2");
      print(widget.videoFile.toString());
      //await FlutterIsolate.spawn(_saveVideoIsolate, widget.videoFile!);
     _saveVideoIsolate(widget.videoFile!.toString());
      print("3");
    }

  }

  void _saveVideoIsolate(String videoFile) async {
    var status = await Permission.storage.request();
    if (status.isGranted) {
      _onLoading(true, '');

      final appDirectory = await getExternalStorageDirectory();
      final destinationDirectory = Directory('${appDirectory?.path}/wa_status_saver');

      if (!destinationDirectory.existsSync()) {
        destinationDirectory.createSync(recursive: true);
      }

      final curDate = DateTime.now().toString();
      final newFileName = '${destinationDirectory.path}/VIDEO-$curDate.mp4';

      try {
        // Copy the file directly
        await File(videoFile).copy(newFileName);

        _onLoading(
          false,
          'If Video not available in gallery\n\nYou can find all videos at',
        );
      } catch (e) {
        print('Error: $e');
        _onLoading(false, 'Error saving the video');
      }
    } else {
      // Handle the case when storage permission is not granted
      print('Permission denied');
    }
  }
}