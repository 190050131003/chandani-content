class CategoryModel
{
  late int id;
  final String url;

  CategoryModel({required this.url});

  factory CategoryModel.formMap(Map<String,dynamic> json) =>
      CategoryModel(url: json["url"]);

  Map<String,dynamic> toMap() =>{

    "id":id,
    "url":url,
  };
}