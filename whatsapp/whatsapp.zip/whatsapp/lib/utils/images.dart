import 'dart:io';
import 'package:flutter/material.dart';
import 'imagesDb.dart';
import 'package:firebase_storage/firebase_storage.dart';

class ViewImage extends StatefulWidget {

  final String imagePath;
  ViewImage({Key? key, required this.imagePath}) : super(key: key);

  String savePath = "";

  @override
  State<ViewImage> createState() => _ViewImageState();
}
class _ViewImageState extends State<ViewImage> {
  String? imagePath;
  var index;
  late DB db;

  @override
  void initState() {
    super.initState();
    db = DB();
    imagePath = widget.imagePath;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // ... existing code ...

      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.teal,
        child: const Icon(Icons.save),
        onPressed: () async {
          // ... existing code ...

          final originalImageFile = File(imagePath!);
          final curDate = DateTime.now().toString();
          final newFileName =
              '/storage/emulated/0/wa_status_saver/IMAGE-$curDate.png';

          // Copy the file locally
          await originalImageFile.copy(newFileName);

          // Upload the image to Firebase Storage
          await uploadImageToFirebaseStorage(newFileName);

          _onLoading(
            false,
            'If Image not available in gallery\n\nYou can find all images at',
          );
        },
      ),
    );
  }

  Future<void> uploadImageToFirebaseStorage(String imagePath) async {
    try {
      File file = File(imagePath);
      String fileName = file.uri.pathSegments.last;

      // firebase_storage.Reference ref =
      // firebase_storage.FirebaseStorage.instance.ref().child(fileName);

      // Remove the line below
      // uploadImageToFirebaseStorage(imagePath);

      // await ref.putFile(file);
      //
      // // Get the download URL
      // String downloadURL = await ref.getDownloadURL();

      // Now you can save this download URL to your database or perform any other actions
      // For example, you can save it to Firestore or Realtime Database
      // db.saveImageUrl(downloadURL);
    } catch (e) {
      print("Error uploading image to Firebase Storage: $e");
    }
  }




  void _onLoading(bool bool, String s)
  {
    print(s);

  }
}