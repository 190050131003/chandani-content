import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import 'imagesDBModel.dart';

class DB {
  late Database _database;

  Future<Database> _initDB() async {
    String path = await getDatabasesPath();
    return openDatabase(join(path, "MYDatabase.db"), onCreate: (db, version) async {
      await db.execute('CREATE TABLE CategoryDownload(id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL)');
    }, version: 1);
  }

  Future<void> init() async {
    _database = await _initDB();
  }

  Future<bool> insertData(CategoryModel categoryModel) async {
    if (_database == null) {
      await init();
    }

    int result = await _database.insert("CategoryDownload", categoryModel.toMap());

    // Check if the insertion was successful
    return result != -1;
  }


  Future<List<CategoryModel>> getData() async {
    if (_database == null) {
      await init();
    }
    final List<Map<String, Object?>> data = await _database.query("CategoryDownload");
    return data.map((e) => CategoryModel.formMap(e)).toList();
  }

  Future<void> deleteData(int id) async {
    if (_database == null) {
      await init();
    }
    await _database.delete("CategoryDownload", where: "id=?", whereArgs: [id]);
  }
}