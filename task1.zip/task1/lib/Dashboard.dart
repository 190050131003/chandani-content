import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

import 'Login.dart';

class Dashboard extends StatefulWidget
{

  @override
  DashboardState createState() => DashboardState();

}

class DashboardState extends State<Dashboard>
{
  TextEditingController Category = TextEditingController();
  TextEditingController ProductName = TextEditingController();
  TextEditingController PurchasePrice = TextEditingController();
  TextEditingController SellingPrice = TextEditingController();
  TextEditingController Margin = TextEditingController();

  late String MobileNo, Password;
  late SharedPreferences logindata;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title:

        Text(
          "       Add Product list",
          style: TextStyle(
            color: Colors.black,
          ),
        ),
        backgroundColor: Colors.white,
        actions: [
          PopupMenuButton<String>(
            color: Colors.black,
            onSelected: (value) {
              if (value == 'logout')
              {
                logout(); // Call the logout method when the logout option is selected.
              }
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              PopupMenuItem<String>(
                value: 'logout',
                child: Text('Logout', style: TextStyle(color: Colors.white),),
              ),
            ],
          ),
        ],
      ),


      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.all(7.0),
              padding: EdgeInsets.all(10.0),

              width: 300,
              height: 40,

              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
              ),
              child: TextField(
                textAlign: TextAlign.start,
                controller: Category,
                decoration: InputDecoration(
                  border: InputBorder.none,

                  icon: Icon(Icons.perm_identity_outlined, color: Colors.black,),
                  hintText: "Enter Category of Stationary",
                  contentPadding: EdgeInsets.symmetric(vertical: 7),

                ),
              ),
            ),

            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.all(7.0),
              padding: EdgeInsets.all(10.0),

              width: 300,
              height: 40,

              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
              ),
              child: TextField(
                textAlign: TextAlign.start,
                controller: ProductName,
                decoration: InputDecoration(
                  border: InputBorder.none,

                  icon: Icon(Icons.person_outline_outlined, color: Colors.black,),
                  hintText: "Enter Product Name",
                  contentPadding: EdgeInsets.symmetric(vertical: 7),

                ),
              ),
            ),

            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.all(7.0),
              padding: EdgeInsets.all(10.0),

              width: 300,
              height: 40,

              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
              ),
              child: TextField(
                textAlign: TextAlign.start,
                controller: PurchasePrice,
                decoration: InputDecoration(
                  border: InputBorder.none,

                  icon: Icon(Icons.perm_identity_outlined, color: Colors.black,),
                  hintText: "Enter Purchased Price",
                  contentPadding: EdgeInsets.symmetric(vertical: 7),

                ),
              ),
            ),

            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.all(7.0),
              padding: EdgeInsets.all(10.0),

              width: 300,
              height: 40,

              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
              ),
              child: TextField(
                textAlign: TextAlign.start,
                controller: SellingPrice,
                decoration: InputDecoration(
                  border: InputBorder.none,

                  icon: Icon(Icons.perm_identity_outlined, color: Colors.black,),
                  hintText: "Enter Selling Price",
                  contentPadding: EdgeInsets.symmetric(vertical: 7),

                ),
              ),
            ),

            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.all(7.0),
              padding: EdgeInsets.all(10.0),

              width: 300,
              height: 40,

              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
              ),
              child: TextField(
                textAlign: TextAlign.start,
                controller: Margin,
                decoration: InputDecoration(
                  border: InputBorder.none,

                  icon: Icon(Icons.perm_identity_outlined, color: Colors.black,),
                  hintText: "Enter Margin",
                  contentPadding: EdgeInsets.symmetric(vertical: 7),

                ),
              ),
            ),

         SizedBox(height: 20),

         TextButton(
          onPressed: ()
          {
            var url=Uri.parse("https://begrimed-executions.000webhostapp.com/Product/Product_insert.php");
            http.post(url,

                body:
                {

                  "Category":Category.text.toString(),
                  "ProductName":ProductName.text.toString(),
                  "PurchasePrice":PurchasePrice.text.toString(),
                  "SellingPrice":SellingPrice.text.toString(),
                  "Margin":Margin.text.toString(),


                }

            );
            print(Category.text.toString());
            print(ProductName.text.toString());
            print(PurchasePrice.text.toString());
            print(SellingPrice.text.toString());
            print(Margin.text.toString());


            Navigator.push(context, MaterialPageRoute(builder: (context) => Dashboard()));
          },
          style: TextButton.styleFrom(
            primary: Colors.white,
            backgroundColor: Colors.blue,
          ), child: Text("Submit"),
         ),
          ],
        ),
      ),
    );
  }

  void logout() async
  {
      logindata = await SharedPreferences.getInstance();
      logindata.setBool('login', true); // Set the login flag back to true.
      Navigator.pushReplacement(context as BuildContext, MaterialPageRoute(builder: (context) => LoginPage()), // Navigate to the Login page.
      );

  }
}
