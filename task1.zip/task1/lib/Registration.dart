import 'package:api_task_application/Dashboard.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;


enum GenderSelect {Male , Female}
class RegistrationPage extends StatefulWidget
{
  @override
  RegistrationState createState() => RegistrationState();


}

class RegistrationState extends State<RegistrationPage>
{

  TextEditingController FirstName = TextEditingController();
  TextEditingController LastName = TextEditingController();
  TextEditingController Email = TextEditingController();
  TextEditingController MobileNo = TextEditingController();
  TextEditingController Password = TextEditingController();

  GenderSelect _gender = GenderSelect.Male;


  @override
  Widget build(BuildContext context)
  {
    return Scaffold(
      backgroundColor: Colors.black,
         body: SingleChildScrollView(
           scrollDirection: Axis.vertical,

           child: Column(
             mainAxisAlignment: MainAxisAlignment.center,
             children: [
               SizedBox(height: 70,),

              Text("Hey there,", style: TextStyle(fontSize: 15, color: Colors.white),),

              SizedBox(height: 10,),

              Text("Create an Account", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),),

               SizedBox(height: 15,),

               Container(
                 alignment: Alignment.center,
                 margin: EdgeInsets.all(7.0),
                 padding: EdgeInsets.all(10.0),

                 width: 300,
                 height: 40,

                 decoration: BoxDecoration(
                   color: Colors.white,
                   borderRadius: BorderRadius.circular(15),
                 ),
                 child: TextField(
                   textAlign: TextAlign.start,
                   controller: FirstName,
                   decoration: InputDecoration(
                     border: InputBorder.none,

                     icon: Icon(Icons.perm_identity_outlined, color: Colors.black,),
                     hintText: "First Name",
                     contentPadding: EdgeInsets.symmetric(vertical: 7),

                   ),
                 ),
               ),

               Container(
                 alignment: Alignment.center,
                 margin: EdgeInsets.all(7.0),
                 padding: EdgeInsets.all(10.0),

                 width: 300,
                 height: 40,

                 decoration: BoxDecoration(
                   color: Colors.white,
                   borderRadius: BorderRadius.circular(15),
                 ),
                 child: TextField(
                   textAlign: TextAlign.start,
                   controller: LastName,
                   decoration: InputDecoration(
                     border: InputBorder.none,

                     icon: Icon(Icons.person_outline_outlined, color: Colors.black,),
                     hintText: "Last Name",
                     contentPadding: EdgeInsets.symmetric(vertical: 7),

                   ),
                 ),
               ),

               Container(
                 alignment: Alignment.center,
                 margin: EdgeInsets.all(7.0),
                 padding: EdgeInsets.all(10.0),

                 width: 300,
                 height: 40,

                 decoration: BoxDecoration(
                   color: Colors.white,
                   borderRadius: BorderRadius.circular(15),
                 ),
                 child: Row(
                   children: [
                     Icon(Icons.person_outline_outlined, color: Colors.black,),

                     SizedBox(width: 16),

                     Text("Gender", style: TextStyle(color: Colors.black87),),

                     SizedBox(width: 4),

                     Radio(
                         value: GenderSelect.Male,
                         groupValue: _gender,
                         onChanged: (GenderSelect? value) {
                           setState(()
                           {
                             _gender = value!;

                           });

                         },
                       ),

                      Text("Male"),

                      Radio(
                        value: GenderSelect.Female,
                        groupValue: _gender,
                         onChanged: (GenderSelect? value) {

                           setState(() {

                             _gender = value!;


                           });
                         },
                       ),
                     Text("Female"),
                   ],
                 ),

               ),


               Container(
                 alignment: Alignment.center,
                 margin: EdgeInsets.all(7.0),
                 padding: EdgeInsets.all(10.0),

                 width: 300,
                 height: 40,

                 decoration: BoxDecoration(
                   color: Colors.white,
                   borderRadius: BorderRadius.circular(15),
                 ),
                 child: TextField(
                   textAlign: TextAlign.start,
                   controller: Email,
                   decoration: InputDecoration(
                     border: InputBorder.none,

                     icon: Icon(Icons.email_outlined, color: Colors.black,),
                     hintText: "Email",
                     contentPadding: EdgeInsets.symmetric(vertical: 7),

                   ),
                 ),
               ),

               Container(
                 alignment: Alignment.center,
                 margin: EdgeInsets.all(7.0),
                 padding: EdgeInsets.all(10.0),

                 width: 300,
                 height: 40,

                 decoration: BoxDecoration(
                   color: Colors.white,
                   borderRadius: BorderRadius.circular(15),
                 ),
                 child: TextField(
                   textAlign: TextAlign.start,
                   controller: MobileNo,
                   decoration: InputDecoration(
                     border: InputBorder.none,

                     icon: Icon(Icons.phone_outlined, color: Colors.black,),
                     hintText: "Mobile No",
                     contentPadding: EdgeInsets.symmetric(vertical: 7),

                   ),
                 ),
               ),

               Container(
                 alignment: Alignment.center,
                 margin: EdgeInsets.all(7.0),
                 padding: EdgeInsets.all(10.0),

                 width: 300,
                 height: 40,

                 decoration: BoxDecoration(
                   color: Colors.white,
                   borderRadius: BorderRadius.circular(15),
                 ),
                 child: TextField(
                   textAlign: TextAlign.start,
                    controller: Password,
                   obscureText: true,
                   decoration: InputDecoration(
                     border: InputBorder.none,

                     icon: Icon(Icons.lock_outline, color: Colors.black,),
                     hintText: "Password",
                     contentPadding: EdgeInsets.symmetric(vertical: 7),

                   ),
                 ),
               ),

               SizedBox(height: 20),

               TextButton(
                 onPressed: ()
                 {
                   var url=Uri.parse("https://begrimed-executions.000webhostapp.com/NEW_TASK/databaseInsert.php");
                   http.post(url,

                       body:
                       {

                         "FirstName":FirstName.text.toString(),
                         "LastName":LastName.text.toString(),
                         "Gender":_gender.toString(),
                         "Email":Email.text.toString(),
                         "MobileNo":MobileNo.text.toString(),
                         "Password":Password.text.toString(),


                       }

                   );
                   print(FirstName.text.toString());
                   print(LastName.text.toString());
                   print(_gender.toString());
                   print(Email.text.toString());
                   print(MobileNo.text.toString());
                   print(Password.text.toString());


                   Navigator.push(context, MaterialPageRoute(builder: (context) => Dashboard()));
                 },
                 style: TextButton.styleFrom(
                   primary: Colors.white,
                   backgroundColor: Colors.blue,
                 ),

                 child: Container(
                   alignment: Alignment.center,

                   width: 200,
                   height: 30,


                   child: Text("Register",style: TextStyle(fontSize: 20, color: Colors.white,),),
                   // Text Color
                 ),
               ),

               SizedBox(height: 20),

               Text("Or Register With", style: TextStyle(fontSize: 15, color: Colors.white),),

               SizedBox(height: 20),

               Row(
                 children: [
                   SizedBox(width: 20),
                   ElevatedButton.icon(
                     onPressed: ()
                     {
                       facebook();
                     },
                     icon: Image.asset("asset/facebook.png", height: 20, width: 20,),
                     label: Text(" Facebook"),
                     style: ElevatedButton.styleFrom(
                       primary: Colors.blueGrey,
                       padding: EdgeInsets.only(left: 30, right: 30, top: 10, bottom: 10),
                     ),
                   ),
                   SizedBox(width: 10),

                   ElevatedButton.icon(
                     onPressed: ()
                     {
                       google();
                     },
                     icon: Image.asset("asset/google.png", height: 20, width: 20),
                     label: Text("Google"),
                     style: ElevatedButton.styleFrom(
                       primary: Colors.blueGrey,
                       padding: EdgeInsets.only(left: 40, right: 40,top: 10, bottom: 10),
                     ),
                   ),
                 ],
               ),
               SizedBox(height: 10),

               Row(
                 mainAxisAlignment: MainAxisAlignment.center,
                 children: [
                   Text("Already have an account?", style: TextStyle(fontSize: 15, color: Colors.white),),

                   TextButton(
                     onPressed: ()
                     {
                       Navigator.pop(context);
                     },
                     child: Text("Login", style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white),),),
                 ],
               ),
             ],
         ),
       ),
    );
  }

  void facebook() async
  {

    var url = Uri.parse("https://www.facebook.com/");
    if (await canLaunchUrl(url))
    {
    await launchUrl(url);
    }
    else
    {
    throw 'Could not launch $url';
    }
  }

  void google() async
  {
    var url = Uri.parse("https://www.google.com/");
    if (await canLaunchUrl(url))
    {
    await launchUrl(url);
    }
    else
    {
    throw 'Could not launch $url';
    }
  }
}