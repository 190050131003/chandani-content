import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class MyDb
{
   Database? db;

   Future open() async {
     var databasePath = await getDatabasesPath();
     String path = join(databasePath, 'demo.db');
     print(path);

     db = await openDatabase(path, version: 1,
         onCreate: (Database db, int version) async {
           await db.execute('''
    CREATE TABLE IF NOT EXISTS USERS (
      id INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      des TEXT NOT NULL,
      date TEXT NOT NULL,
      time TEXT NOT NULL,
      priority TEXT NOT NULL
    );
    ''');

           print("Table Created");
         });
   }


   Future<Map<dynamic , dynamic>?> getUser(String name) async
  {
    List<Map> maps = (await db?.query('users',
      where: 'name = ?',
      whereArgs: [name]
    ))!.cast<Map>();

    if(maps.length > 0)
      {
        return maps.first;
      }
    return null;
  }

  // static Future<int>addData(String name, String des, String date, String time, String priority) async
  // {
  //   final db = await
  // }
}