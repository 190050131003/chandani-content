import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:module5/db.dart';

import 'EditData.dart';

class ViewData extends StatefulWidget
{
  @override
  ViewState createState() => ViewState();

}

class ViewState extends State<ViewData>
{
  List<Map> ulist = [];

  MyDb mydb = new MyDb();

  TextEditingController searchController = TextEditingController();
  List<Map> filteredList = [];

  bool isHighlighted = false;
  int highlightedIndex = -1;
  Set<String> completedTasks = Set();

  @override

  void initState() {
    super.initState();
    mydb.open();
    getdata();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Widget build(BuildContext context)
  {
    return Scaffold(
      appBar: AppBar(title: Text("Details"),),

      body: SingleChildScrollView(
        child: Container(

          child: ulist.length == 0 ? Text("No any Users to Show") :
          Column(

            children: <Widget>[

              Padding(padding: EdgeInsets.all(16.0),
                  child: TextField(
                    controller: searchController,
                    onSubmitted: (text)
                    {
                      showWordDetails(text);
                    },

                    decoration: InputDecoration(
                      labelText: "Search by Task Name",
                      prefixIcon: Icon(Icons.search),
                    ),
                  ),
              ),
              for (int index = 0; index < ulist.length; index++)
                Card(
                  child: CustomListTile(
                    title: ulist[index]["name"],
                    subtitle: " Description: ${ulist[index]["des"]} \n Date: ${ulist[index]["date"]} \n Time: ${ulist[index]["time"]} \n Priority: ${ulist[index]["priority"]}",
                    trailing: Wrap(
                      children: [

                        IconButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) {
                              return EditData(name: ulist[index]["name"]);
                            }),
                            );
                          },
                          icon: Icon(Icons.edit, color: Colors.blue),
                        ),

                        IconButton(
                          onPressed: () {
                            mydb.db!.rawDelete("DELETE FROM users where name = ? ", [ulist[index]["name"]]);
                            print("Data Deleted");
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("User Data Deleted")));
                            getdata();
                          },
                          icon: Icon(Icons.delete, color: Colors.red),
                        ),

                        PopupMenuButton(
                            onSelected: (value) {
                              if (value == "complete") {
                                markTaskAsComplete(filteredList[index]["name"]);
                              }
                            },
                            itemBuilder: (BuildContext context)
                        {
                          return <PopupMenuEntry<String>>[
                            const PopupMenuItem<String>(
                              value: "complete",
                              child: Text("Complete the Task"),
                            ),
                          ];
                        })
                      ],
                    ),
                    priority: ulist[index]["priority"],
                    isHighlighted: index == highlightedIndex,
                  ),

                ),
            ],

          )
      ),
      ),
    );
  }

  void getdata()
  {
    Future.delayed(Duration(milliseconds: 500),() async
    {

      ulist = (await mydb.db!.rawQuery('SELECT * FROM users ORDER BY date, time')).cast<Map>();
      showWordDetails(searchController.text);
      setState(() {

      });
    }

    );
  }

  void showWordDetails(String word) {
    // Find the word details in the ulist
    Map? wordDetails;
    for (int i = 0; i < ulist.length; i++) {
      if (ulist[i]["name"].toLowerCase() == word.toLowerCase()) {
        wordDetails = ulist[i];
        break;
      }
    }

    if (wordDetails != null) {
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text(wordDetails?["name"]),
            content: Text(
              "Description: ${wordDetails?["des"]}\n"
                  "Date: ${wordDetails?["date"]}\n"
                  "Time: ${wordDetails?["time"]}\n"
                  "Priority: ${wordDetails?["priority"]}",
            ),
          );
        },
      );
    } else {
      // Handle the case when the word is not found in the ulist
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text('Name not found'),
            content: Text('The Details was not found.'),
          );
        },
      );
    }
  }


  void markTaskAsComplete(String taskName) {
    setState(() {
      // Update the completedTasks set for both ulist and filteredList
      completedTasks.add(taskName);
      for (int i = 0; i < ulist.length; i++) {
        if (ulist[i]["name"] == taskName) {
          ulist[i]["completed"] = true;
        }
      }
      for (int i = 0; i < filteredList.length; i++) {
        if (filteredList[i]["name"] == taskName) {
          filteredList[i]["completed"] = true;
        }
      }
    });
  }
}
class CustomListTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget trailing;
  final String priority;

  CustomListTile({required this.title, required this.subtitle, required this.trailing, required this.priority, required bool isHighlighted});

  @override
  Widget build(BuildContext context)
  {
    Color taskColor;
    switch (priority)
    {
      case 'High':
        taskColor = Colors.red;
        break;

      case 'Average':
        taskColor = Colors.blue;
        break;

      case 'Low':
        taskColor = Colors.green;
        break;

      default:
        taskColor = Colors.white;
    }


    return ListTile(

      tileColor: taskColor,
      title: Text(title),
      subtitle: Text(subtitle),
      trailing: trailing,
    );
  }
}
