// import 'dart:convert';
// import 'dart:core';
//
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:http/http.dart' as http;
// import 'package:travel_guidance_app/Registration.dart';
// import 'package:travel_guidance_app/home.dart';
//
//
// class Login extends StatefulWidget {
//   @override
//   _LoginState createState() => _LoginState();
// }
//
// class _LoginState extends State<Login>
// {
//   final _formKey = GlobalKey<FormState>();
//   late String mobileno,password;
//   late SharedPreferences logindata;
//
//   late bool newuser;
//   var isLoading = false;
//
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     check_if_already_login();
//   }
//   void check_if_already_login() async
//   {
//     logindata = await SharedPreferences.getInstance();
//     newuser = (logindata.getBool('login') ?? true);
//     print(newuser);
//     if (newuser == false) {
//       Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => HomePage()));
//     }
//   }
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.blueGrey,
//       body: Form(
//         key: _formKey,
//         child: Column(
//
//           children: [
//             SizedBox(height: MediaQuery.of(context).size.width * 0.2),
//
//             Container(
//               margin: EdgeInsets.only(left: 25),
//               width: 350,
//               child: Column(
//                 children: [
//                   SizedBox(height: 100,),
//
//                   Text("Welcome Back",style: TextStyle(color: CupertinoColors.white,fontSize: 25,fontWeight: FontWeight.bold),),
//
//                   SizedBox(height: 25,),
//
//                   Container(
//                     height: 50,
//                     width: 280,
//                     padding: EdgeInsets.only(left: 20),
//                     margin: EdgeInsets.only(left: 22, right: 22, bottom: 22),
//                     decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(15),
//                       color: Colors.white,
//                     ),
//                     child: TextFormField(
//                       decoration: InputDecoration(
//                         labelText: "Mobile No",
//                       ),
//                       keyboardType: TextInputType.number,
//                       onFieldSubmitted: (value) {
//
//                       },
//                       validator: (value) {
//                         mobileno = value!;
//                         if (value == null || value.isEmpty)
//                         {
//                           return 'Please enter a phone number';
//                         }
//
//                         return null;
//                       },
//                     ),
//                   ),
//
//                   SizedBox(height: 20,),
//
//                   Container(
//                     height: 50,
//                     width: 280,
//                     padding: EdgeInsets.only(left: 20),
//                     margin: EdgeInsets.only(left: 22, right: 22, bottom: 10),
//                     decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(15),
//                       color: Colors.white,
//                     ),
//                     child: TextFormField(
//                       decoration: InputDecoration(
//                         labelText: "Password",
//                       ),
//                       keyboardType: TextInputType.text,
//                       obscureText: true,
//                       onFieldSubmitted: (value) {
//
//                       },
//                       validator: (value) {
//                         password = value!;
//                         if (value == null || value.isEmpty)
//                         {
//                           return 'Please enter a Password';
//                         }
//
//                         return null;
//                       },
//                     ),
//                   ),
//
//                   SizedBox(height: 20,),
//
//                   // GestureDetector(
//                   //   onTap: onTapText,
//                   //   child: Text('Forgot Your Password?', style: TextStyle(decoration: TextDecoration.underline,color: CupertinoColors.white),),
//                   // ),
//
//                   // SizedBox(height: 20,),
//
//                   Container(
//                     height: 40,
//                     width: 250,
//                     margin: EdgeInsets.only(left: 80, right: 80, top: 30, bottom: 20),
//                     decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(15),
//                       color: Colors.white,
//                     ),
//                     child: ElevatedButton(
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: Colors.white,
//                       ),
//
//                       onPressed: ()
//                       async {
//                         _Login();
//                         var url = Uri.parse("https://begrimed-executions.000webhostapp.com/travel_guidance.php/Login.php");
//
//                         var response = await http.post(url, body:
//                         {
//
//                           "mobileno": mobileno.toString(),
//                           "password": password.toString(),
//
//
//                         });
//                         var data = json.decode(response.body);
//                         if(data==0)
//                         {
//                           print("fail2");
//                         }
//                         else
//                         {
//                           print("success2");
//
//                         }
//
//                       },
//                       child: Text('Login', style: TextStyle(fontSize: 16, color: Colors.black),),
//                     ),
//                   ),
//
//                   SizedBox(height: 20,),
//
//                   //"Don't have an account yer? Register
//                   GestureDetector(
//                     onTap: onTap,
//                     child: Text("Don't have an account yer? Register", style: TextStyle(color: CupertinoColors.white),),
//                   ),
//
//
//                 ],
//               ),
//             ),
//
//           ],
//         ),
//       ),
//     );
//   }
//
//
//   void onTap()
//   {
//     Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => AddData()));
//   }
//
//   void _Login()
//   {
//     final isValid  = _formKey.currentState?.validate();
//     if(!isValid!)
//     {
//       return ;
//     }
//     else
//     {
//       _formKey.currentState?.save();
//       String Mobileno = mobileno;
//       String Password = password;
//       if(Mobileno != '' && Password !='')
//       {
//         print('success');
//         logindata.setBool('login', false);
//         logindata.setString('mobileno', Mobileno);
//         Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
//
//
//       }
//     }
//   }
// }