// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'package:travel_guidance_app/Login.dart';
// import 'package:travel_guidance_app/constants.dart';
// import 'package:travel_guidance_app/home.dart';
//
// class AddData extends StatefulWidget
// {
//   @override
//   AddState createState() => AddState();
//
// }
//
// class AddState extends State<AddData>
// {
//   List<String> citiesList = <String>
//   [
//     city1,
//     city2,
//     city3,
//     city4,
//   ];
//
//   String? selectCity = city1;
//
//   TextEditingController name = TextEditingController();
//   TextEditingController email = TextEditingController();
//   TextEditingController password = TextEditingController();
//   TextEditingController mobileno = TextEditingController();
//
//
//   @override
//   Widget build(BuildContext context)
//   {
//     return Scaffold(
//       backgroundColor: Colors.blueGrey,
//
//       appBar: AppBar(title: Text("Travelling Guidance App"),),
//       body: ListView(
//
//           children: [
//
//             SizedBox(height: 110,),
//
//             Container(
//               alignment: Alignment.center,
//               height: 50,
//               width: 70,
//               padding: EdgeInsets.only(left: 20),
//               margin: EdgeInsets.only(left: 22, right: 22, bottom: 22),
//               decoration: BoxDecoration(
//                 borderRadius: BorderRadius.circular(15),
//                 color: Colors.white
//               ),
//               child: TextField(
//                 controller: name ,
//                 decoration: InputDecoration(hintText: "Enter Your Name",),
//               ),
//             ),
//
//             Container(
//               height: 50,
//               width: 70,
//               padding: EdgeInsets.only(left: 20),
//               margin: EdgeInsets.only(left: 22, right: 22, bottom: 22),
//               decoration: BoxDecoration(
//                 borderRadius: BorderRadius.circular(15),
//                 color: Colors.white,
//               ),
//               child: TextField(
//                 controller: email,
//                 decoration: InputDecoration(hintText: "Enter Your Email",),
//               ),
//             ),
//
//             Container(
//               height: 50,
//               width: 70,
//               padding: EdgeInsets.only(left: 20),
//               margin: EdgeInsets.only(left: 22, right: 22, bottom: 22),
//               decoration: BoxDecoration(
//                 borderRadius: BorderRadius.circular(15),
//                 color: Colors.white
//               ),
//               child: TextField(
//                 controller: password ,
//                 decoration: InputDecoration(hintText: "Enter Your Password",),
//               ),
//             ),
//
//             Container(
//               height: 50,
//               width: 70,
//               padding: EdgeInsets.only(left: 20),
//               margin: EdgeInsets.only(left: 22, right: 22, bottom: 22),
//               decoration: BoxDecoration(
//                 borderRadius: BorderRadius.circular(15),
//                 color: Colors.white,
//               ),
//               child: TextField(
//                 controller: mobileno ,
//                 decoration: InputDecoration(hintText: "Enter Your Mobile No",),
//               ),
//             ),
//
//             Container(
//               height: 50,
//               width: 70,
//               padding: EdgeInsets.only(left: 20),
//               margin: EdgeInsets.only(left: 22, right: 22, bottom: 22),
//               decoration: BoxDecoration(
//                 borderRadius: BorderRadius.circular(15),
//                 color: Colors.white,
//               ),
//               child: DropdownButton<String>(
//                 hint: Row(
//                   children: [
//                     Icon(Icons.location_on),
//                     SizedBox(width: 17,),
//                     const Text("City"),
//                   ],
//                 ),
//                 isExpanded: true,
//                 value: selectCity,
//                 items: citiesList.map((String value)
//                 {
//                   return DropdownMenuItem<String>
//                     (
//                     value: value,
//                     child: Row(
//                       children: [
//                         Icon(Icons.location_on),
//                         SizedBox(width: 17,),
//                         Text(value),
//
//                       ],
//                     ),
//                   );
//                 }).toList(),
//
//                 onChanged: (newValue)
//                 {
//                   FocusScope.of(context).requestFocus(FocusNode());
//                   FocusScope.of(context).requestFocus(FocusNode());
//                   setState(() {
//                     selectCity = newValue!;
//                   });
//                 },
//               ),
//             ),
//
//             Container(
//               height: 40,
//               width: 50,
//                 margin: EdgeInsets.only(left: 80, right: 80, top: 30, bottom: 20),
//                 decoration: BoxDecoration(
//                   borderRadius: BorderRadius.circular(15),
//                   color: Colors.white,
//                 ),
//               child:
//               ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: Colors.white,
//                 ),
//                   onPressed: ()
//                   {
//
//                 //insertdata();
//                 var url=Uri.parse("https://begrimed-executions.000webhostapp.com/travel_guidance.php/Registration.php");
//                 http.post(url,
//
//                     body:
//                     {
//
//                       "name": name.text.toString(),
//                       "email": email.text.toString(),
//                       "password": password.text.toString(),
//                       "mobileno": mobileno.text.toString(),
//                       "city": selectCity.toString(),
//
//                     }
//
//                 );
//
//                 print('Inserted');
//
//                 Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
//
//
//               }, child: Text("Submit", style: TextStyle(color: Colors.black, fontSize: 16),)),
//             ),
//
//             Container(
//               padding: EdgeInsets.only(left: 75, top: 15),
//               child: GestureDetector(
//                 onTap: ()
//                 {
//                   Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
//                 },
//                 child: Text("Already have an Account? Login", style: TextStyle(color: Colors.white),),
//               ),
//             )
//
//
//             // Container(
//             //   height: 40,
//             //   width: 50,
//             //   margin: EdgeInsets.only(left: 80, right: 80, top: 10, bottom: 30),
//             //   decoration: BoxDecoration(
//             //     borderRadius: BorderRadius.circular(15),
//             //     color: Colors.white,
//             //   ),
//             //   child: ElevatedButton(
//             //       style: ElevatedButton.styleFrom(
//             //         backgroundColor: Colors.white,
//             //       ),
//             //       onPressed: (){
//             //
//             //     Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
//             //
//             //   }, child: Text("View Data", style: TextStyle(fontSize: 16, color: Colors.black),)),
//             // )
//
//           ]
//       ),
//     );
//   }
//
// }