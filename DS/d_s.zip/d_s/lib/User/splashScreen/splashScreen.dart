import 'dart:async';
import 'package:digital_society1/User/home/Complaints.dart';
import 'package:digital_society1/User/home/NoticeBoard.dart';
import 'package:digital_society1/User/home/Parking/Parking.dart';
import 'package:digital_society1/User/home/ServiceProviders.dart';
import 'package:digital_society1/User/register/register.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

import '../../Admin/home/adminNoticeBoard/adminNoticeBoard.dart';
import '../home/members.dart';
import '../login/login.dart';

class splashScreen extends StatefulWidget {
  const splashScreen({super.key});

  @override
  State<splashScreen> createState() => _splashScreenState();
}

class _splashScreenState extends State<splashScreen>
{
  @override
  void initState() {
    Timer(Duration(seconds: 8), () =>
        Navigator.pushReplacement(
            context, MaterialPageRoute(
            builder: (context) =>
                LoginPage())));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          children: [
            Lottie.network("https://deducible-dabs.000webhostapp.com/lottie/digital_society.json",
            height: 500,
              repeat: true,
              reverse: true,
              animate: true,
            ),
          ],
        ),
      ),
    );
  }
}
