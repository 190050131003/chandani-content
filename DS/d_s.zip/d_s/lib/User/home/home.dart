import 'package:digital_society1/Admin/home/adminServiceProviders/adminServiceProvider.dart';
import 'package:digital_society1/Admin/home/adminVisitors.dart';
import 'package:digital_society1/User/constants.dart';
import 'package:digital_society1/User/home/Parking/Parking.dart';
import 'package:flutter/material.dart';

import 'Complaints.dart';
import 'Events/Events.dart';
import 'NoticeBoard.dart';
import 'ServiceProviders.dart';
import 'members.dart';

class homePage extends StatefulWidget {
  const homePage({super.key});

  @override
  State<homePage> createState() => _homePageState();
}

class _homePageState extends State<homePage>
{
  int _selectedIndex = 0;

  List<String> names =
  [
    name1,
    name2,
    name3,
    name4,
    name5,
    name6,
    name7,
    name8,
    name9,
    name10,
    name11,
    name12,
  ];

  List<String> icons =
  [
    icon1,
    icon2,
    icon3,
    icon4,
    icon5,
    icon6,
    icon7,
    icon8,
    icon9,
    icon10,
    icon11,
    icon12,
  ];

  late List<String> jsonData;

  get category_name => null;

  get userDataList => null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple,
      appBar: AppBar(title: Text("Smart Society"),
      backgroundColor: Colors.deepPurple,
        actions: [
          IconButton(
              onPressed: ()
              {

              }, icon: Icon(Icons.notifications))
        ],
      ),

      drawer: Drawer(
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: [
            const UserAccountsDrawerHeader(
              decoration: BoxDecoration(color: Colors.white),
              accountName: Text(
                "UserName",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              currentAccountPicture: CircleAvatar(
                radius: 80.0, // Adjust the size as needed
                backgroundImage: AssetImage("images/members.png"),
                backgroundColor: Colors.deepPurple,
              ),
              accountEmail: Text("user@gmail.com"),
            ),
            ListTile(
              leading: Icon(
                Icons.folder,
                color: Colors.black,
              ),
              title: const Text('All files', style: TextStyle(color: Colors.black),),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(
                Icons.watch_later,
                color: Colors.black,
              ),
              title: const Text('Recent', style: TextStyle(color: Colors.black),),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(
                Icons.photo_library_rounded,
                color: Colors.black,
              ),
              title: const Text('Images', style: TextStyle(color: Colors.black),),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(
                Icons.my_library_music,
                color: Colors.black,
              ),
              title: const Text('Sounds', style: TextStyle(color: Colors.black),),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(
                Icons.archive,
                color: Colors.black,
              ),
              title: const Text('Archieved', style: TextStyle(color: Colors.black),),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(
                Icons.delete,
                color: Colors.black,
              ),
              title: const Text('Trash', style: TextStyle(color: Colors.black),),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(
                Icons.settings,
                color: Colors.black,
              ),
              title: const Text('Settings', style: TextStyle(color: Colors.black),),
              onTap: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
      body: Center(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(0),
              child: Image.asset("images/home.jpg"),
            ),
            SizedBox(height: 5,),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  color: Colors.deepPurple,
                  child: GridView.builder(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 7.0,
                      mainAxisSpacing: 7.0,
                      childAspectRatio: 0.9,
                    ),
                    itemCount: icons.length,
                    itemBuilder: (BuildContext context, int index) {
                      return GestureDetector(
                        onTap: () async
                        {
                          switch (index) {
                            case 0:
                              if (names[index] == name1 && icons[index] == icon1) {
                                Navigator.push(context, MaterialPageRoute(builder: (context) => Members()));
                              }
                              break;
                            case 1:
                              if (names[index] == name2 && icons[index] == icon2) {
                                Navigator.push(context, MaterialPageRoute(builder: (context) => NoticeBoard()));
                              }
                              break;
                            case 3:
                              if (names[index] == name4 && icons[index] == icon4) {
                                Navigator.push(context, MaterialPageRoute(builder: (context) => Category(index: index, category_name: category_name)));
                              }
                              break;
                            case 7:
                              if (names[index] == name8 && icons[index] == icon8) {
                                Navigator.push(context, MaterialPageRoute(builder: (context) => Parking()));
                              }
                              break;
                            case 5:
                              if (names[index] == name6 && icons[index] == icon6) {
                                Navigator.push(context, MaterialPageRoute(builder: (context) => ServiceProviders()));
                              }
                              break;
                            case 9:
                              if (names[index] == name10 && icons[index] == icon10) {
                                Navigator.push(context, MaterialPageRoute(builder: (context) => Complaints()));
                              }
                              break;
                            case 4:
                              if (names[index] == name5 && icons[index] == icon5) {
                                Navigator.push(context, MaterialPageRoute(builder: (context) => adminVisitors(userDataList: userDataList)));
                              }
                            case 2:
                              if (names[index] == name3 && icons[index] == icon3) {
                                Navigator.push(context, MaterialPageRoute(builder: (context) => adminServiceProvider()));
                              }

                            default:
                            // Handle default case if needed
                          }
                        },

                        child: Column(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(4.0),
                              child: Container(
                                alignment: Alignment.center,
                                height: 120,
                                width: 200,
                                color: Colors.white,
                                child: Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        height: 60, // Adjust the height of the image
                                        decoration: BoxDecoration(
                                          image: DecorationImage(
                                            image: AssetImage(icons[index]),
                                            fit: BoxFit.contain, // Adjust the fit to contain the image within the container
                                          ),
                                        ),
                                      ),
                                      Text(names[index],
                                        textAlign: TextAlign.center,
                                      ),
                                    ],
                                  )
                                  ),
                                ),
                              ),
                          ],
                        ),
                         // Replace with your actual item widget
                      );
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.deepPurple,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.grey,
        currentIndex: _selectedIndex,
          onTap: _onItemTapped,
        items: [
          BottomNavigationBarItem(
              icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.room_service),
          label: "Services",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.messenger_outlined),
            label: "Chat"
          ),
        ],
      ),
    );
  }

  void _onItemTapped(int value)
  {
    setState(() {
      _selectedIndex = value;
    });
  }
}
