import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Members extends StatefulWidget
{
  @override
  MembersState createState() => MembersState();

}

class MembersState extends State<Members>
{
  late List list;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Members"),
        backgroundColor: Colors.deepPurple,
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('images/background_image.jpg'),
                repeat: ImageRepeat.repeat,
                fit: BoxFit.fill,
              ),
            ),
          ),
          Center(
            child: FutureBuilder<List>(
                future: getdetail(),
                builder:(ctx,ss){

                  if(ss.hasData)
                  {

                    return Items(list:ss.data!);

                  }
                  if(ss.hasError)
                  {
                    print('Network Not Found');
                  }

                  return CircularProgressIndicator();



                }),
          ),
        ],
      ),
    );
  }

  Future<List>getdetail()async
  {
    var response = await http.get(Uri.parse("https://begrimed-executions.000webhostapp.com/digital_society/register.php/register_view.php"));
    return jsonDecode(response.body);
  }
}

class Items extends StatelessWidget
{
  List list;
  Items({required this.list});

  @override
  Widget build(BuildContext context)
  {

    return ListView.builder(

      itemCount: list==null?0:list.length,
      itemBuilder: (ctx,i)
      {

        return Container(
          padding: EdgeInsets.all(5),
          margin: EdgeInsets.only(top: 10, left: 15, right: 15, bottom: 10),
          height: 100,
          width: 60,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            boxShadow: [
              BoxShadow(
                color: Colors.deepPurple.withOpacity(0.7),
                spreadRadius: 3,
                blurRadius: 3,
                offset: Offset(0, 2), // changes the position of the shadow
              ),
            ],
          ),
          child: ListTile(


              title: Text("${list[i]['FirstName']} " " ${list[i]['LastName']}", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),),
              subtitle: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 80,
                    width: MediaQuery.of(context).size.width,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Gender: ${list[i]['Gender']}", style: TextStyle(color: Colors.white),),
                        Text("Address(Wing): ${list[i]['Address']}", style: TextStyle(color: Colors.white),),
                        Text("Email: ${list[i]['Email']}", style: TextStyle(color: Colors.white),),
                      ],
                    ),
                  ),
                ],
              )
          ),
        );
      },
    );
  }
}

class member {
  final String firstName;
  final String lastName;
  final String gender;
  final String address;
  final String email;
  final String mobileNo;
  final String password;

  member({
    required this.firstName,
    required this.lastName,
    required this.gender,
    required this.address,
    required this.email,
    required this.mobileNo,
    required this.password,
  });

  factory member.fromJson(Map<String, dynamic> json) {
    return member(
      firstName: json['FirstName'],
      lastName: json['LastName'],
      gender: json['Gender'],
      address: json['Address'],
      email: json['Email'],
      mobileNo: json['MobileNo'],
      password: json['Password'],
    );
  }
}

