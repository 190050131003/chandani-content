import 'package:flutter/material.dart';

import 'FourWheel.dart';
import 'TwoWheel.dart';

class Parking extends StatefulWidget {
  const Parking({Key? key}) : super(key: key);

  @override
  State<Parking> createState() => _ParkingState();
}

class _ParkingState extends State<Parking> with SingleTickerProviderStateMixin
{
  TabController? _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    if (_tabController == null) {
      // Handle the case where _tabController is null
      return CircularProgressIndicator();
    }

    return Scaffold(
      appBar: AppBar(
        title: Text("Parking Slot"),
        backgroundColor: Colors.deepPurple,
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(text: 'FOUR WHEEL',),
            Tab(text: "TWO WHEEL",),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          FourWheel(),
          TwoWheel(),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _tabController?.dispose();
    super.dispose();
  }
}
