import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class TwoWheel extends StatefulWidget {
  @override
  State<TwoWheel> createState() => _TwoWheelState();
}

class _TwoWheelState extends State<TwoWheel>
{
  late List list;
  TextEditingController flatNo = TextEditingController();
  TextEditingController vehicleNo = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('images/background_image.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Center(
            child: Column(
              children: [
                SizedBox(height: 10,),
                Container(
                  padding: EdgeInsets.only(left: 20, right: 20),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: Colors.deepPurple, width: 4)
                  ),
                  height: 190,
                  width: 300,
                  child: Column(
                    children: [
                      TextField(
                        decoration: InputDecoration(
                          labelText: "Flat No",
                          labelStyle: TextStyle(color: Colors.deepPurple),
                          enabledBorder: UnderlineInputBorder(
                            borderSide:
                            BorderSide(color: Colors.deepPurple), //<-- SEE HERE
                          ),
                        ),
                      ),
                      TextField(
                        decoration: InputDecoration(
                          labelText: "Vehicle No",
                          labelStyle: TextStyle(color: Colors.deepPurple),
                          enabledBorder: UnderlineInputBorder(
                            borderSide:
                            BorderSide(color: Colors.deepPurple), //<-- SEE HERE
                          ),
                        ),
                      ),
                      SizedBox(height: 10,),
                      ElevatedButton(
                        onPressed: ()
                        {
                          _addVehicle();
                        },
                        child: Text("ADD",),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple),
                      )
                    ],
                  ),
                ),
                SizedBox(height: 10,),
                Expanded(
                  child: FutureBuilder<List>(
                    future: getDetail(),
                    builder: (ctx, ss) {
                      if (ss.hasData) {
                        return Items(list: ss.data!);
                      }
                      if (ss.hasError) {
                        print('Network Not Found');
                      }
                      return Center(child: CircularProgressIndicator());
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<List> getDetail() async {
    var response = await http.get(Uri.parse("https://begrimed-executions.000webhostapp.com/digital_society/register.php/register_view.php"));
    return jsonDecode(response.body);
  }

  void _addVehicle()
  {
    setState(() {
      print("Clicked");
      var url = Uri.parse("https://begrimed-executions.000webhostapp.com/digital_society/service_providers.php/insert.php");
      http.post(
        url,
        body: {
          "flatNo": flatNo.text.toString(),
          "vehicleNo": vehicleNo.text.toString(),
        },
      );
      flatNo.text = "";
      vehicleNo.text = "";
      print("Data sent successfully");
    });
  }

}

class Items extends StatelessWidget {
  List list;
  Items({required this.list});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: list == null ? 0 : list.length,
      itemBuilder: (ctx, i) {
        return Container(
          padding: EdgeInsets.all(5),
          margin: EdgeInsets.only(top: 15, left: 20, right: 20, bottom: 10),
          height: 100,
          width: 60,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            boxShadow: [
              BoxShadow(
                color: Colors.deepPurple.withOpacity(0.7),
                spreadRadius: 3,
                blurRadius: 3,
                offset: Offset(0, 2), // changes the position of the shadow
              ),
            ],
          ),
          child: ListTile(
            title: Text("Category : ${list[i]['category']}",
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
            subtitle: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: 80,
                  width: MediaQuery.of(context).size.width,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 7,
                      ),
                      Text("Name : ${list[i]['name']}",
                          style: TextStyle(
                              color: Colors.white, fontWeight: FontWeight.bold)),
                      SizedBox(
                        height: 7,
                      ),
                      Text("MobileNo : ${list[i]['mobileNo']}",
                          style: TextStyle(
                              color: Colors.white, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
