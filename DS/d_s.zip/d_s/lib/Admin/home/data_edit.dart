import 'package:digital_society1/Admin/home/adminMembers.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Edit extends StatefulWidget
{

  Edit();


  @override
  _EditState createState() => _EditState();

}

class _EditState  extends State<Edit>
{
  TextEditingController FirstName = TextEditingController();
  TextEditingController LastName = TextEditingController();
  TextEditingController Address = TextEditingController();
  TextEditingController Email = TextEditingController();
  TextEditingController MobileNo = TextEditingController();


  @override
  void initState()
  {
    super.initState();
  }


  @override
  Widget build(BuildContext context)
  {
    return Scaffold(

      appBar:  AppBar(

        title: Text("Edit Data"),
      ),

      body: Container(
        decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('images/background_image.jpg'),
              fit: BoxFit.cover,
            )
        ),
        child: ListView(
          children: [
            TextFormField(
              textAlign: TextAlign.start,
              controller: FirstName,
              decoration: InputDecoration(
                border: InputBorder.none,

                icon: Icon(Icons.perm_identity_outlined, color: Colors.black,),
                hintText: "First Name",
                contentPadding: EdgeInsets.symmetric(vertical: 7),

              ),
              keyboardType: TextInputType.text,
              onFieldSubmitted: (value) {

              },
              validator: (value)
              {
                if(value!.isEmpty)
                {
                  return "Please Enter FirstName";
                }
                return null;
              },
            ),

            TextFormField(
              textAlign: TextAlign.start,
              controller: LastName,
              decoration: InputDecoration(
                border: InputBorder.none,

                icon: Icon(Icons.person_outline_outlined, color: Colors.black,),
                hintText: "Last Name",
                contentPadding: EdgeInsets.symmetric(vertical: 7),

              ),
              keyboardType: TextInputType.text,
              onFieldSubmitted: (value) {

              },
              validator: (value)
              {
                if(value!.isEmpty)
                {
                  return "Please Enter LastName";
                }
                return null;
              },
            ),

            TextFormField(
              textAlign: TextAlign.start,
              controller: Address,
              decoration: InputDecoration(
                border: InputBorder.none,

                icon: Icon(Icons.person_outline_outlined, color: Colors.black,),
                hintText: "Address(Flat No)",
                contentPadding: EdgeInsets.symmetric(vertical: 7),

              ),
              keyboardType: TextInputType.text,
              onFieldSubmitted: (value) {

              },
              validator: (value)
              {
                if(value!.isEmpty)
                {
                  return "Please Enter Address";
                }
                return null;
              },
            ),

            TextFormField(
              textAlign: TextAlign.start,
              controller: Email,
              decoration: InputDecoration(
                border: InputBorder.none,

                icon: Icon(Icons.email_outlined, color: Colors.black,),
                hintText: "Email",
                contentPadding: EdgeInsets.symmetric(vertical: 7),

              ),
              keyboardType: TextInputType.emailAddress,
              onFieldSubmitted: (value) {

              },
              validator: (value)
              {
                if(value!.isEmpty || !RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value))
                {
                  return "Please Enter a valid Email";
                }
                return null;
              },
            ),

            TextFormField(
              textAlign: TextAlign.start,
              controller: MobileNo,
              decoration: InputDecoration(
                border: InputBorder.none,

                icon: Icon(Icons.phone_outlined, color: Colors.black,),
                hintText: "Mobile No",
                contentPadding: EdgeInsets.symmetric(vertical: 7),

              ),
              keyboardType: TextInputType.number,
              onFieldSubmitted: (value) {

              },
              validator: (value)
              {
                if(value!.isEmpty || !RegExp(r"^\d{10}$").hasMatch(value))
                {
                  return "Please Enter Valid Mobileno";
                }
                return null;
              },
            ),

            MaterialButton(
              child: Text("Save"),
              onPressed: (){
                editData();
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (BuildContext context)=> adminMembers()),
                );
              },
            )
          ],
        ),
      ),
    );
  }

  void editData()
  {
    var url =Uri.parse("https://begrimed-executions.000webhostapp.com/digital_society/register.php/register_view.php");
    http.post(url,body: {

      'FirstName': FirstName.text.toString(),
      'LastName': LastName.text.toString(),
      'Email': Email.text.toString(),
      'MobileNo': MobileNo.text.toString(),
    });


  }

}