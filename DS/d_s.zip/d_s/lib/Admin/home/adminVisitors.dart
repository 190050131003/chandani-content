import 'package:flutter/material.dart';

class UserData {
  final String firstName;
  final String lastName;
  final String address;

  UserData({
    required this.firstName,
    required this.lastName,
    required this.address,
  });
}

class adminVisitors extends StatefulWidget {
  final List<UserData> userDataList;

  const adminVisitors({required this.userDataList, Key? key}) : super(key: key);

  @override
  State<adminVisitors> createState() => _adminVisitorsState();
}

class _adminVisitorsState extends State<adminVisitors> {
  String selectedAddress = '';
  List<UserData> filteredUserDataList = [];

  @override
  Widget build(BuildContext context) {
    // Populate filteredUserDataList based on selectedAddress
    filteredUserDataList = widget.userDataList
        .where((userData) => userData.address == selectedAddress)
        .toList();

    return Scaffold(
      appBar: AppBar(title: Text("Visitors"),),
      body: Center(
        child: Column(
          children: [
            // DropdownButton to select Wing (Address)
            DropdownButton<String>(
              value: selectedAddress,
              onChanged: (String? newValue) {
                setState(() {
                  selectedAddress = newValue!;
                });
              },
              items: widget.userDataList
                  .map((userData) => userData.address)
                  .toSet()
                  .toList()
                  .map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),

            // Display user details for the selected address
            ListView.builder(
              shrinkWrap: true,
              itemCount: filteredUserDataList.length,
              itemBuilder: (BuildContext context, int index) {
                return ListTile(
                  title: Text(filteredUserDataList[index].firstName),
                  subtitle: Text(filteredUserDataList[index].lastName),
                  // Add more details as needed
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
