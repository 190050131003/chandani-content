import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class adminNoticeBoard extends StatefulWidget {

  @override
  State<adminNoticeBoard> createState() => _adminNoticeBoardState();
}

class _adminNoticeBoardState extends State<adminNoticeBoard>
{
  @override
  void initState() {
    super.initState();
    fetchInstructions();
  }

  TextEditingController text = TextEditingController();
  TextEditingController choice = TextEditingController();
  List<Map<String, dynamic>> instructions = [];

  Future<void> fetchInstructions() async {
    final response = await http.get(
      Uri.parse("https://your_server/fetch_instructions.php"), // Update with your server URL
    );

    if (response.statusCode == 200) {
      // Successful response
      final List<Map<String, dynamic>> fetchedInstructions = response.body as List<Map<String, dynamic>>;
      setState(() {
        instructions = fetchedInstructions;
      });
    } else {
      // Error handling
      print("Error: ${response.statusCode}");
      print("Body: ${response.body}");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Notice"),
      backgroundColor: Colors.deepPurple,
      ),
      body: Container(
        decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('images/background_image.jpg'),
              fit: BoxFit.cover,
              repeat: ImageRepeat.repeat
            )
        ),
        child: SingleChildScrollView(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: 50,),
                Container(
                  height: 200,
                  width: 350,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.deepPurple,
                      width: 2.0,
                    ),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: TextField(
                    controller: text,
                    decoration: InputDecoration(
                      labelText: "Enter Message",
                      labelStyle: TextStyle(color: Colors.deepPurple),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.only(left: 20, top: 20, right: 20, bottom: 10),
                    ),
                    keyboardType: TextInputType.multiline,
                    maxLines: null,
                    expands: true,
                  ),
                ),
                SizedBox(height: 10,),

                ElevatedButton(
                    onPressed: ()
                    {
                      saveToDatabase(text.text);
                    },
                    child: Text("Send"),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple),
                ),

                SizedBox(height: 70,),

                Container(
                  height: 200,
                  width: 350,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.deepPurple,
                      width: 2.0,
                    ),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: TextField(
                    controller: choice,
                    decoration: InputDecoration(
                      labelText: "Enter Message for choice(YES and NO)",
                      border: InputBorder.none,
                      labelStyle: TextStyle(color: Colors.deepPurple),
                      contentPadding: EdgeInsets.only(left: 20, top: 20, right: 20, bottom: 10),
                    ),
                    keyboardType: TextInputType.multiline,
                    maxLines: null,
                    expands: true,
                  ),
                ),
                SizedBox(height: 10.0),

                ElevatedButton(
                    onPressed: ()
                    {
                      saveToDatabase(choice.text);
                    },
                    child: Text("Send"),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> saveToDatabase(String s) async {
    final response = await http.post(
      Uri.parse("https://your_server/save_instruction.php"), // Update with your server URL
      body: {
        'text': text.text,
        'choice': choice.text,
      },
    );

    if (response.statusCode == 200) {
      // Successful response
      print(response.body);
      // Update the instructions list after saving to the database
      fetchInstructions();
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Message saved successfully"),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text("OK"),
              ),
            ],
          );
        },
      );
    } else {
      // Error handling
      print("Error: ${response.statusCode}");
      print("Body: ${response.body}");
    }
  }

  Future<void> handleResponse(int choiceId, String response) async {
    final response = await http.post(
      Uri.parse("https://your_server/handle_response.php"), // Update with your server URL
      body: {
        'choice_id': choiceId.toString(),
        // 'response': response,
      },
    );

    if (response.statusCode == 200) {
      // Successful response
      print(response.body);
      // Update the instructions list after handling the response
      fetchInstructions();
    } else {
      // Error handling
      print("Error: ${response.statusCode}");
      print("Body: ${response.body}");
    }
  }
}
