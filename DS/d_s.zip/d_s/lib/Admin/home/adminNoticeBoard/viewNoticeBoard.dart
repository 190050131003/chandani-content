import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class viewNoticeBoard extends StatefulWidget {
  const viewNoticeBoard({super.key});

  @override
  State<viewNoticeBoard> createState() => _viewNoticeBoardState();
}

class _viewNoticeBoardState extends State<viewNoticeBoard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Notice"),
        backgroundColor: Colors.deepPurple,
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('images/background_image.jpg'),
                  fit: BoxFit.cover,
                )
            ),
          ),
          Center(
            child: SingleChildScrollView(
              child: FutureBuilder<List>(
                  future: getdetail(),
                  builder:(ctx,ss){

                    if(ss.hasData)
                    {

                      return Items(list:ss.data!);

                    }
                    if(ss.hasError)
                    {
                      print('Network Not Found');
                    }

                    return CircularProgressIndicator();

                  }
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<List>getdetail()async
  {
    var response = await http.get(Uri.parse("https://begrimed-executions.000webhostapp.com/digital_society/register.php/register_view.php"));
    return jsonDecode(response.body);
  }
}

class Items extends StatelessWidget
{
  List list;
  Items({required this.list});

  @override
  Widget build(BuildContext context)
  {

    return Container(
      child: ListView.separated(

        itemCount: list==null?0:list.length,
        itemBuilder: (ctx,i)
        {

          return ListTile(


              title: Text("${list[i]['FirstName']} " " ${list[i]['LastName']}"),
              subtitle: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 80,
                    width: MediaQuery.of(context).size.width,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Gender: ${list[i]['Gender']}"),
                        Text("Address: ${list[i]['Address']}", style: TextStyle(color: Colors.black),),
                        Text("Email: ${list[i]['Email']}"),
                        Text("MobileNo: ${list[i]['MobileNo']}"),
                      ],
                    ),
                  ),
                ],
              )
          );
        }, separatorBuilder: (BuildContext context, int index)
      {
        return Divider(
          height: 4,
          thickness: 2,
          color: Colors.black,
        );
      },


      ),
    );
  }
}

class member {
  final String firstName;
  final String lastName;
  final String gender;
  final String email;
  final String mobileNo;
  final String password;

  member({
    required this.firstName,
    required this.lastName,
    required this.gender,
    required this.email,
    required this.mobileNo,
    required this.password,
  });

  factory member.fromJson(Map<String, dynamic> json) {
    return member(
      firstName: json['FirstName'],
      lastName: json['LastName'],
      gender: json['Gender'],
      email: json['Email'],
      mobileNo: json['MobileNo'],
      password: json['Password'],
    );
  }
}
