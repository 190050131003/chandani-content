import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:project_1/screens/user/front/front.dart';

class PhoneAuthScreen extends StatefulWidget {
  final String mobile_no;

  PhoneAuthScreen({required this.mobile_no, required String username, required String password, required String confirm_password, required String identifier});

  @override
  _PhoneAuthScreenState createState() => _PhoneAuthScreenState();
}

class _PhoneAuthScreenState extends State<PhoneAuthScreen>
{
  var username = TextEditingController();
  var password = TextEditingController();
  var confirm_password = TextEditingController();
  var mobile_no = TextEditingController();
  String identifier = 'user';
  final TextEditingController _smsController = TextEditingController();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  String _verificationId = '';

  @override

  void initState() {
    // TODO: implement initState
    super.initState();
    _verifyPhone();
  }
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Phone Authentication'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextFormField(
              controller: _smsController,
              decoration: InputDecoration(labelText: 'Enter OTP'),
            ),
            ElevatedButton(
              onPressed: () {
                _verifyPhone();
                Navigator.push(context, MaterialPageRoute(builder: (context) => Front()));
              },
              child: Text('Verify OTP'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _verifyPhone() async {
    try {
      final formattedPhoneNumber = '+91${widget.mobile_no}';

      await _auth.verifyPhoneNumber(
        phoneNumber: formattedPhoneNumber,
        verificationCompleted: (PhoneAuthCredential credential) async {
          await _auth.signInWithCredential(credential);
          // Return true to indicate successful OTP verification
          Navigator.pop(context, true);

           insertData();
        },
        verificationFailed: (FirebaseAuthException e) {
          print('Verification failed: ${e.message}');
        },
        codeSent: (String verificationId, int? resendToken) {
          setState(() {
            _verificationId = verificationId;
          });
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          if (mounted) {
            print('Auto retrieval timed out');
          }
        },
      );
    } catch (e) {
      print('Error: $e');
    }
  }

  void insertData() {
    try {
      var url =
          "https://begrimed-executions.000webhostapp.com/Project_1/register.php/register_insert.php";
      http.post(Uri.parse(url), body: {
        "username": username.text.toString(),
        "password": password.text.toString(),
        "confirm_password": confirm_password.text.toString(),
        "mobile_no": mobile_no.text.toString(),
        "identifier": identifier,
      });
    } catch (e) {
      print('Error inserting data: $e');
    }
  }
}