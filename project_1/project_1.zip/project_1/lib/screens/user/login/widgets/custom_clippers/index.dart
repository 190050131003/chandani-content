export 'brown_top_clipper.dart';
export 'gold_top_clipper.dart';
export 'lightgold_top_clipper.dart';