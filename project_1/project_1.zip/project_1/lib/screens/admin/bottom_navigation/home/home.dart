import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import '../../../constants.dart';
import '../../category/category.dart';
import '../../front/front.dart';
import 'package:permission_handler/permission_handler.dart';

class AdminHome extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return AdminHomePage();
  }
}

class AdminHomePage extends State<AdminHome>
{

  PickedFile? _imageFile;

  Future<List> viewCategoryData() async {
    try {
      final response = await http.get(Uri.parse("https://begrimed-executions.000webhostapp.com/Project_1/category.php/category_view.php"));
      print("Response: ${response.body}");
      return jsonDecode(response.body);
    } catch (error) {
      print("Error fetching data: $error");
      return [];
    }
  }


  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async {
        Navigator.pushReplacement(
          context,
          PageRouteBuilder(
            pageBuilder: (a, b, c) => AdminFront(),
            transitionDuration: Duration(seconds: 3),
          ),
        );
      },
      child: Scaffold(
        backgroundColor: kLightGold,
        body: FutureBuilder<List>(
          future: viewCategoryData(),
          builder: (ctx, ss) {
            if (ss.hasData) {
              return Items(list: ss.data!);
            } else {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
          },
        ),
      ),
    );
  }
}


class Items extends StatefulWidget
{
   List list;
  Items({required this.list});

  @override
  State<StatefulWidget> createState() {
    return _Items(list_: list);
  }
}

class _Items extends State<Items>
{

     late List list_;
     //_Items({required this.list_});
     //_Items({required List<dynamic> list_});
     _Items({required this.list_});

  var size;

  var update_category = TextEditingController();

  late PickedFile _imageFile;
  final String uploadUrl = "https://begrimed-executions.000webhostapp.com/upload_category/upload_category_main_image_update.php";
     final ImagePicker _picker = ImagePicker();

     // void _pickImage(var id) async {
     //   try {
     //     final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
     //     if (pickedFile != null) {
     //       print("Picked image path: ${pickedFile.path}");
     //       setState(() {
     //         _imageFile = pickedFile as PickedFile;
     //       });
     //       await uploadImage(_imageFile.path, uploadUrl + "?id=" + id.toString());
     //     } else {
     //       print("Image picking canceled");
     //     }
     //   } catch (e) {
     //     print("Image picker error: $e");
     //   }
     // }


     Future<void> requestPermission() async {
       var status = await Permission.photos.request();
       if (status.isGranted) {
         // Permission granted, proceed with image picking/uploading
       } else {
         // Permission denied, handle accordingly
       }
     }

     Future<void> _pickImage(list_) async {
       try {
         final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
         if (pickedFile != null) {
           setState(() {
             _imageFile = (pickedFile as PickedFile?)!;
           });
         }
       } catch (e) {
         print("Image picker error: $e");
       }
     }




     // Future<String> uploadImage(String filepath, String url) async {
     //   try {
     //     var request = http.MultipartRequest('POST', Uri.parse(url));
     //     request.files.add(await http.MultipartFile.fromPath('profile_pic', filepath));
     //     var res = await request.send();
     //     print("Upload response: ${res.reasonPhrase}");
     //     return res.reasonPhrase!;
     //   } catch (e) {
     //     print("Upload error: $e");
     //     return "Upload failed";
     //   }
     // }

     Future<void> uploadImage() async {
       try {
         var request = http.MultipartRequest('POST', Uri.parse('YOUR_UPLOAD_URL'));
         request.files.add(await http.MultipartFile.fromPath('file', _imageFile!.path));
         var response = await request.send();

         if (response.statusCode == 200) {
           // Image uploaded successfully
           print("Image uploaded successfully");
         } else {
           // Handle upload failure
           print("Image upload failed: ${response.statusCode}");
         }
       } catch (e) {
         print("Image upload error: $e");
       }
     }


     void deleteCategory(var id){
    var url = "https://begrimed-executions.000webhostapp.com/Project_1/category.php/category_delete.php";
    http.post(Uri.parse(url),body: {
      'data': id,
    });
  }

  void deleteCategoryImages(var id){
    var url = "https://begrimed-executions.000webhostapp.com/Project_1/category_images.php/category_images_delete.php";
    http.post(Uri.parse(url),body: {
      'data': id,
    });
  }

  void updateCategoryName(var id){
    var url = "https://begrimed-executions.000webhostapp.com/Project_1/category.php/category_update.php";
    http.post(Uri.parse(url),body: {
      'id': id,
      'category_name': update_category.text,
    });
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;

    return ListView.builder(
      itemCount: list_.length,
      itemBuilder: (BuildContext context,int index){
        return Card(
          color: kGold,
          shadowColor: kBrown,
          elevation: 3,
          child: ListTile(
            onTap: (){
              Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context)=>AdminCategory(index: list_[index]['id'],category_name: list_[index]['category_name'])));
            },
            leading: Icon(Icons.list,color: kBrown,),
            trailing: InkWell(
              onTap: (){
                showDialog(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    backgroundColor: kWhite,
                    title: Row(children: [Icon(Icons.delete, color: kBrown,),Text("\tDelete", style: TextStyle(color: kBrown),)],),
                    content: Text("This items will be permanently deleted.",style: TextStyle(color: kTerracotta ,fontStyle: FontStyle.italic)),
                    actions: <Widget>[
                      TextButton(
                        onPressed: () {
                          Navigator.of(ctx).pop();
                        },
                        child: Text("Cancel",style: TextStyle(color: kBrown)),
                      ),
                      TextButton(
                        onPressed: () {
                          deleteCategory(list_[index]['id']);
                          deleteCategoryImages(list_[index]['id']);
                          Fluttertoast.showToast(msg: "Category Deleted Successfully",toastLength: Toast.LENGTH_LONG,timeInSecForIosWeb: 1);
                          Navigator.of(context).pop();
                        },
                        child: Text("Delete",style: TextStyle(color: kBrown)),
                      ),
                    ],
                  ),
                );
              },
              child: Icon(Icons.delete,size: 25, color: kBrown,),
            ),
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                SizedBox(
                  width: size.width*55/100,
                  child: Text("${list_[index]['category_name']}".toUpperCase(),style: TextStyle(color: kDarkBrown ,fontStyle: FontStyle.italic,fontSize: 15)),
                ),
                InkWell(
                  onTap: (){
                    update_category.text = list_[index]['category_name'];
                    showDialog(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        backgroundColor: kWhite,
                        title: Row(children: [Icon(Icons.update, color: kBrown,),Text("\tUpdate Category",style: TextStyle(color: kBrown))],),
                        content: Container(
                          height: size.height*14/100,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              TextField(
                                controller: update_category,
                                decoration: InputDecoration(
                                  hintText: "Input Category Name",
                                ),
                              ),
                              // SizedBox(height: size.height*1/100),
                              ConstrainedBox(
                                constraints: const BoxConstraints(
                                  minWidth: double.infinity,
                                ),
                                child: TextButton(
                                  style: TextButton.styleFrom(
                                    backgroundColor: kBrown,
                                    padding: const EdgeInsets.all(kPaddingM),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(4.0),
                                    ),
                                  ),
                                  onPressed: () async
                                  {
                                    // _pickImage(list_[index]['id']);

                                    await _pickImage(list_[index]['id']);
                                    if (_imageFile != null) {
                                      await uploadImage();
                                    }
                                  },
                                  child: Text("Update Image".toUpperCase(),
                                    style: Theme.of(context).textTheme.subtitle1!.copyWith(color: kLightGold,fontStyle: FontStyle.italic),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        actions: <Widget>[
                          TextButton(
                            onPressed: () {
                              Navigator.of(ctx).pop();
                            },
                            child: Text("Cancel",style: TextStyle(color: kBrown)),
                          ),
                          TextButton(
                            onPressed: () {
                              if(!update_category.text.isEmpty){
                                updateCategoryName(list_[index]['id']);
                                Fluttertoast.showToast(msg: "Category Updated Successfully",toastLength: Toast.LENGTH_LONG,timeInSecForIosWeb: 1);
                                Navigator.of(context).pop();
                              }
                              else{
                                if(update_category.text.isEmpty){
                                  Fluttertoast.showToast(msg: "Please Input Category Name",toastLength: Toast.LENGTH_LONG,timeInSecForIosWeb: 1);
                                }
                              }
                            },
                            child: Text("Update",style: TextStyle(color: kBrown)),
                          ),
                        ],
                      ),
                    );
                  },
                  child: Icon(Icons.edit,size: 25,color: kBrown),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}