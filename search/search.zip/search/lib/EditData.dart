import 'package:flutter/material.dart';
import 'package:module5/db.dart';

class EditData extends StatefulWidget {
  final String name;

  EditData({required this.name});

  @override
  EditState createState() => EditState();
}

class EditState extends State<EditData> {
  TextEditingController name = TextEditingController();
  TextEditingController des = TextEditingController();
  TextEditingController date = TextEditingController();
  TextEditingController time = TextEditingController();
  TextEditingController priority = TextEditingController();

  MyDb mydb = MyDb();

  @override
  void initState() {
    mydb.open();

    Future.delayed(Duration(milliseconds: 500), () async {
      var data = await mydb.getUser(widget.name);

      if (data != null) {
        name.text = data["name"];
        des.text = data["des"];
        date.text = data["date"];
        time.text = data["time"];
        priority.text = data["priority"];

        setState(() {});
      }
      else
      {
        print("No data found for name: " + widget.name);
      }
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Edit Data"),
        ),
        body: Container(
        padding: EdgeInsets.all(30),
              child: Column(
              children: [
                TextField(
                  controller: name,
                  decoration: InputDecoration(
                  hintText: "Name",
                  ),
                  ),
                TextField(
                  controller: des,
                  decoration: InputDecoration(
                  hintText: "Description",
                  ),
                  ),
                TextField(
                  controller: date,
                  decoration: InputDecoration(
                  hintText: "Date",
                  ),
                  ),
                TextField(
                  controller: time,
                  decoration: InputDecoration(
                  hintText: "Time",
                  ),
                  ),
                TextField(
                  controller: priority,
                  decoration: InputDecoration(
                  hintText: "Priority",
                  ),
                  ),

                  ElevatedButton(
                    onPressed: () {
                    mydb.db!.rawUpdate(
                    "Update users set name = ?, des = ?, date = ?, time = ?, priority = ? where name = ?",
                    [name.text, des.text, date.text, time.text, priority.text, widget.name],);

                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text("Data Updated"),

                      ),);
                      },child: Text("Save User Data"),
          ),
          ],
          ),
          ),
          );
          }
          }
