import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:module5/ViewData.dart';

import 'db.dart';

class TaskManagement extends StatefulWidget
{
  @override
  TaskManagementState createState() => TaskManagementState();


}

class TaskManagementState extends State<TaskManagement>
{

  TextEditingController name = TextEditingController();
  TextEditingController des = TextEditingController();
  TextEditingController date = TextEditingController();
  TextEditingController time = TextEditingController();

  String? selectedPriority;

  MyDb mydb = MyDb();

  DateTime selecteddate = DateTime.now();
  DateTime selectedtime = DateTime.now();

  String formattedDate = '';
  String formattedTime = '';
  final _formKey = GlobalKey<FormState>();


  @override
  Widget build(BuildContext context)
  {
    return Scaffold(

      appBar: AppBar(title: Text("Task Management"),),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
            child: Column(
            children: [

              SizedBox(height: 50),

              Container(
                margin: EdgeInsets.all(7),
                padding: EdgeInsets.all(10),
                height: 450,
                width: 500,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),

                  boxShadow: [
                BoxShadow(
                color: Colors.grey,
                  offset: const Offset(
                    1.0,
                    1.0,
                  ),
                  blurRadius: 1.0,
                  spreadRadius: 0.0,
                ),
                ]
                ),

                
                child: Column(
                  children: [

                    SizedBox(height: 45),

                    Container(
                      alignment: Alignment.center,
                      margin: EdgeInsets.all(7.0),
                      padding: EdgeInsets.all(12.0),

                      width: 300,
                      height: 45,

                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: TextFormField(
                        controller: name,
                        decoration: InputDecoration(
                          border: InputBorder.none,

                          icon: Icon(Icons.person_outline_outlined, color: Colors.black,),
                          hintText: "Enter Your Name",
                          contentPadding: EdgeInsets.symmetric(vertical: 7),
                        ),

                        keyboardType: TextInputType.text,
                        onFieldSubmitted: (value) {

                        },
                        validator: (value) {
                          final nameText = name.text;
                          if (value == null || value.isEmpty)
                          {
                            return 'Please Enter Name';
                          }

                          return null;
                        },
                      ),
                    ),

                    Container(
                      alignment: Alignment.center,
                      margin: EdgeInsets.all(7.0),
                      padding: EdgeInsets.all(12.0),

                      width: 300,
                      height: 45,

                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: TextFormField(
                        controller: des,
                        textAlign: TextAlign.start,

                        decoration: InputDecoration(
                          border: InputBorder.none,

                          icon: Icon(Icons.description_outlined, color: Colors.black,),
                          hintText: "Description",
                          contentPadding: EdgeInsets.symmetric(vertical: 7),

                        ),

                        keyboardType: TextInputType.text,
                        onFieldSubmitted: (value) {

                        },
                        validator: (value) {
                          final desText = des.text;
                          if (value == null || value.isEmpty)
                          {
                            return 'Please Enter Description';
                          }

                          return null;
                        },

                      ),
                    ),

                    Container(
                        alignment: Alignment.center,
                        margin: EdgeInsets.all(7.0),
                        padding: EdgeInsets.all(5.0),

                        width: 300,
                        height: 45,

                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: Row(
                          children: [
                            SizedBox(width: 9),
                            Icon(Icons.date_range_outlined),
                            TextButton(
                              onPressed: ()
                              {
                                _selectDate(context);

                              }, child: Text("  Date:  $formattedDate",
                              style: TextStyle(
                                  color: Colors.black54),),
                            ),
                          ],
                        ),
                    ),

                    Container(
                        alignment: Alignment.center,
                        margin: EdgeInsets.all(7.0),
                        padding: EdgeInsets.all(5.0),

                        width: 300,
                        height: 45,

                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: Row(
                          children: [
                            SizedBox(width: 9),
                            Icon(Icons.timelapse_outlined),
                            TextButton(
                              onPressed: ()
                              {
                                _selectTime(context);

                              }, child: Text("  Time:  $formattedTime", style: TextStyle(color: Colors.black54),),),
                          ],
                        )
                    ),

                    Container(
                      margin: EdgeInsets.all(7.0),
                      padding: EdgeInsets.all(12.0),

                      width: 300,
                      height: 100,

                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                      ),

                      child: Row(
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(Icons.priority_high_outlined, color: Colors.black),
                                  SizedBox(width: 16),
                                  Text("Priority", style: TextStyle(color: Colors.black87)),
                                ],
                              ),
                              Row(
                                children: [
                                  Radio(
                                    value: "High",
                                    groupValue: selectedPriority,
                                    onChanged: (value) {
                                      setState(() {
                                        selectedPriority = value!;
                                      });
                                    },
                                  ),
                                  Text("High"),

                                  Radio(
                                    value: "Average",
                                    groupValue: selectedPriority,
                                    onChanged: (value) {
                                      setState(() {
                                        selectedPriority = value!;
                                      });
                                    },
                                  ),
                                  Text("Average"),

                                  Radio(
                                    value: "Low",
                                    groupValue: selectedPriority,
                                    onChanged: (value) {
                                      setState(() {
                                        selectedPriority = value!;
                                      });
                                    },
                                  ),
                                  Text("Low"),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 20),

              Container(
                alignment: Alignment.center,
                margin: EdgeInsets.all(7.0),
                padding: EdgeInsets.all(2.0),

                width: 300,
                height: 45,

                decoration: BoxDecoration(
                  color: Colors.grey,
                  borderRadius: BorderRadius.circular(15),
                ),

                child: TextButton(
                  onPressed: () async
                  {

                    try {
                      await mydb.open(); // Open the database
                      await mydb.db!.rawInsert("INSERT INTO USERS (name, des, date, time, priority) VALUES (?, ?, ?, ?, ?);",
                          [name.text, des.text, formattedDate, formattedTime, selectedPriority]);

                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("New User Added")));
                    } catch (e) {
                      print("Error inserting data: $e");
                    }

                    print("Name: ${name.text}");
                    print("Description: ${des.text}");
                    print("Date: $formattedDate");
                    print("Time: $formattedTime");
                    print("Priority: $selectedPriority");



                    name.text = "";
                    des.text = "";
                    date.text = "";
                    time.text = "";
                    selectedPriority = "";

                    print("Inserted");
                  },
                  child: Text("Submit", style: TextStyle(fontSize: 20, color: Colors.black),),

                ),
              ),
              ElevatedButton(
                  onPressed: ()
                  {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => ViewData()));
                  }, child: Text("View Data"))
            ],
            ),
        ),
      ),
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    print('Before date picker: $selecteddate');
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selecteddate,
      firstDate: DateTime(2015, 1),
      lastDate: DateTime(2101),
    );
    print('After date picker: $selecteddate');

    if (picked != null) {
      setState(() {
        selecteddate = picked;
        formattedDate = "${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}";
      });
      print('Formatted date: $formattedDate');
    }
  }

  Future<void> _selectTime(BuildContext context) async
  {
    final TimeOfDay? picked = (
        await showTimePicker(
        context: context,
        initialTime: TimeOfDay.fromDateTime(selectedtime))
    );

    if(picked != null)
    {
      final selectedTime = DateTime(
        selectedtime.year,
        selectedtime.month,
        selectedtime.day,
        picked.hour,
        picked.minute,
      );

      setState(() {
        selectedtime = selectedTime;
        formattedTime = "${picked.hour}:${picked.minute.toString().padLeft(2, '0')}";
      });
    }

  }

}