import 'package:flutter/material.dart';
import 'package:module5/db.dart';
import 'EditData.dart';

class ViewData extends StatefulWidget {
  @override
  ViewState createState() => ViewState();
}

class ViewState extends State<ViewData> {
  List<Map> ulist = [];
  MyDb mydb = new MyDb();
  TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    mydb.open();
    getdata();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Details"),
      ),
      body: SingleChildScrollView(
        child: Container(
          child: ulist.length == 0
              ? Text("No Users to Show")
              : Column(
            children: <Widget>[
              Padding(
                padding: EdgeInsets.all(16.0),
                child: TextField(
                  controller: searchController,
                  onChanged: filterTasks,
                  decoration: InputDecoration(
                    labelText: "Search by Task Name",
                    prefixIcon: Icon(Icons.search),
                  ),
                ),
              ),
              for (int index = 0; index < ulist.length; index++)
                Card(
                  child: CustomListTile(
                    title: ulist[index]["name"],
                    subtitle:
                    " Description: ${ulist[index]["des"]} \n Date: ${ulist[index]["date"]} \n Time: ${ulist[index]["time"]} \n Priority: ${ulist[index]["priority"]}",
                    trailing: Wrap(
                      children: [
                        IconButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (BuildContext context) {
                                  return EditData(name: ulist[index]["name"]);
                                },
                              ),
                            );
                          },
                          icon: Icon(Icons.edit, color: Colors.lightBlue),
                        ),
                        IconButton(
                          onPressed: () {
                            mydb.db!.rawDelete("DELETE FROM users where name = ? ", [ulist[index]["name"]]);
                            print("Data Deleted");
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text("User Data Deleted")),
                            );
                            getdata();
                          },
                          icon: Icon(Icons.delete, color: Colors.redAccent),
                        ),
                      ],
                    ),
                    priority: ulist[index]["priority"],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  void getdata() {
    Future.delayed(Duration(milliseconds: 500), () async {
      ulist = (await mydb.db!.rawQuery('SELECT * FROM users ORDER BY date, time')).cast<Map>();
      setState(() {});
    });
  }

  void filterTasks(String query) {
    if (query.isEmpty) {
      getdata();
    } else {
      List<Map> filteredList = ulist!
          .where((task) =>
      task["name"]!.toLowerCase().contains(query.toLowerCase()) ||
          task["date"]!.toLowerCase().contains(query.toLowerCase()))
          .toList();
      setState(() {
        ulist = filteredList;
      });
    }
  }
}

class CustomListTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget trailing;
  final String priority;

  CustomListTile({
    required this.title,
    required this.subtitle,
    required this.trailing,
    required this.priority,
  });

  Color getPriorityColor(String priority) {
    switch (priority) {
      case 'High':
        return Colors.red;
      case 'Average':
        return Colors.blue;
      case 'Low':
        return Colors.green;
      default:
        return Colors.white;
    }
  }

  @override
  Widget build(BuildContext context) {
    Color taskColor = getPriorityColor(priority);

    return ListTile(
      tileColor: taskColor,
      title: Text(title),
      subtitle: Text(subtitle),
      trailing: trailing,
    );
  }
}
