package com.example.firebase_otp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
