<?php
    
    include('connect.php');
    
    $email1=$_REQUEST["Email"];
    $pass1=$_REQUEST["password"];
    
    $sql="select * mydb where Email='$email1' and password ='$pass1'";
    
    
    $ex=mysqli_query($con,$sql);
    
    $no=mysqli_num_rows($ex);
    
    
    if($no>0)
    {
    $fet=mysqli_fetch_object($ex);
    echo json_encode(['code'=>200]);
    }
    else
    {
    echo "0";
    }

?>