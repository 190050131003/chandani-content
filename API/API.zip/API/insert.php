<?php

    include('connect.php');
    
    $name = $_POST["name"];
    $email = $_POST["email"];


    if($name=="" && $email=="")
    {
        
        echo '0';
        
    }
    else
    {
     
        $sql ="insert into INFO(name,email) values ('$name','$email')";
        mysqli_query($con,$sql);//query run
        
    }


?>