<?php 

     define('HOST','localhost');
     define('USER','id21062154_chandani');
     define('PASS','Chandani@3110');
     define('DB','id21062154_practice');
     
     $con = mysqli_connect(HOST,USER,PASS,DB) or ('unable');
     
     
?>