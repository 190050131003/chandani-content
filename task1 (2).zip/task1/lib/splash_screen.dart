import 'dart:async';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

import 'Login.dart';


class SplashScreen extends StatefulWidget
{
  @override
  SplashState createState() => SplashState();

}

class SplashState extends State<SplashScreen>{

  @override
  void initState() {
    Timer(Duration(seconds: 8), () => Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage()))
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Center(

        child: Column(

          children: [


            SizedBox(width: 300, height: 150),


            Lottie.network("https://begrimed-executions.000webhostapp.com/Animations/stationary.json",
              height: 450,
              repeat: true,
              reverse: true,
              animate: true,

            )
          ],
        ),
      ),
    );
  }
}