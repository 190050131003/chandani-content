import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;


void main()
{
  runApp(MaterialApp(home:MyView()));
}

class MyView extends StatefulWidget
{
  @override
  MYViewState createState() => MYViewState();

}

class MYViewState extends State<MyView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(title: Text("View Details"),),
      body: GridView.count(

        
        crossAxisCount: 2,

        children: List.generate(100, (index) {
          return Center(
            child: Text(
              'Item $index',
              style: Theme
                  .of(context)
                  .textTheme
                  .headlineSmall,),
          );
        }
        ),
      ),
    );
  }
}

