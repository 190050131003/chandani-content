import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as  http;
import 'package:login_form/Login.dart';
import 'package:login_form/Registration.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard>
{
  late String email;

  late SharedPreferences loginData;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initial();
  }

  void initial() async {
    loginData = await SharedPreferences.getInstance();

    setState(() {
      email = loginData.getString('email')!;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Dashboard"),
        actions: [
          IconButton(
              onPressed: ()
              {
                loginData.setBool('login', true);
                setState(() {
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => Login()));
                });
              },
              icon: Icon(Icons.logout))
        ],
      ),

      body: Stack(
        children: [
          FutureBuilder<List>(
              future: getDetail(),
              builder: (ctx, ss)
              {
                if(ss.hasData)
                {
                  return Items(list:ss.data!);
                }
                if(ss.hasError)
                {
                  print("Network not found");
                }
                return CircularProgressIndicator();
              }
          )
        ],
      ),
    );
  }

  Future<List> getDetail() async
  {
    var response = await http.get(Uri.parse("https://begrimed-executions.000webhostapp.com/login_form.php/view.php"));
    return jsonDecode(response.body);
  }
}

class Items extends StatelessWidget
{
  List list;
  Items({required this.list});

  @override
  Widget build(BuildContext context)
  {
    return ListView.builder(
        itemBuilder: (ctx, i)
        {
          if(i<list.length)
          {
            return Container(
              margin: EdgeInsets.only(left: 20, right: 20, top: 40,),
              padding: EdgeInsets.only(left: 15, right: 15,top: 8),
              height: 170,
              width: 100,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.6),
                        spreadRadius:3,
                        blurRadius: 3,
                        offset:Offset(0,2)
                    )]
              ),

              child: ListTile(
                title: Text("Name: ${list[i]['firstName']} " " ${list[i]['lastName']}", style: TextStyle(color: Colors.white),),
                subtitle: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Gender: ${list[i]['gender']}", style: TextStyle(color: Colors.white),),
                        Text("Hobbies: ${list[i]['hobbies']}", style: TextStyle(color: Colors.white),),
                        Text("City: ${list[i]['city']}", style: TextStyle(color: Colors.white),),
                        Text("Email: ${list[i]['email']}", style: TextStyle(color: Colors.white),),
                        Text("Password: ${list[i]['Password']}", style: TextStyle(color: Colors.white),),
                        Text("ConfirmPassword: ${list[i]['confirmPassword']}", style: TextStyle(color: Colors.white),),
                        Text("MobileNo: ${list[i]['mobileNo']}", style: TextStyle(color: Colors.white),),
                      ],
                    ),
                  ],
                ),
              ),
            );
          }


        });
  }
}
class member {
  final String firstName;
  final String lastName;
  final String gender;
  final String hobbies;
  final String city;
  final String email;
  final String password;
  final String confirmPassword;
  final String mobileNo;

  member({
    required this.firstName,
    required this.lastName,
    required this.gender,
    required this.hobbies,
    required this.city,
    required this.email,
    required this.password,
    required this.confirmPassword,
    required this.mobileNo,
  });

  factory member.fromJson(Map<String, dynamic> json) {
    return member(
      firstName: json['firstName'],
      lastName: json['lastName'],
      gender: json['gender'],
      hobbies: json['hobbies'],
      city: json['city'],
      email: json['email'],
      password: json['password'],
      confirmPassword: json['confirmPassword'],
      mobileNo: json['mobileNo'],

    );
  }
}
