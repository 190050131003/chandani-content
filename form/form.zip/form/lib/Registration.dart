import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:login_form/Dashboard.dart';
import 'package:login_form/Login.dart';

enum genderSelect {Male, Female}
class Registration extends StatefulWidget {
  const Registration({super.key});

  @override
  State<Registration> createState() => _RegistrationState();
}

class _RegistrationState extends State<Registration>
{
  String city = "Vadodara";
  final _formKey = GlobalKey<FormState>();
  TextEditingController firstName = TextEditingController();
  TextEditingController lastName = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController confirmPassword = TextEditingController();
  TextEditingController mobileNo = TextEditingController();

  List<String> hobbies = <String> [];
  genderSelect _gender = genderSelect.Male;
  bool value = false;
  List<bool> hobbiesCheckedList = List.filled(4, false);
  int selectedIndex = 1;
  List<String> hobbiesList = <String> [
    "Travelling",
    "Singing",
    "Dancing",
    "Drawing",
  ];

  List<String> citiesList = <String> [
    "Vadodara",
    "Rajkot",
    "Ahmedabad",
    "Bangalore",
    "Delhi",
    "Mumbai",
    "Vapi",
    "Surat",
    "Hyderabad",
    "Pune",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 50,),
              Text("Register", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),),
              Container(
                margin: EdgeInsets.only(left: 30, right: 20, top: 20,),
                padding: EdgeInsets.only(left: 10,),
                height: 50,
                width: 300,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black54, width: 2),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: TextFormField(
                  controller: firstName,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    icon: Icon(Icons.person, color: Colors.black,),
                    hintText: "First Name",
                    enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.white,)
                    ),
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Colors.white)
                    ),
                  ),
                  validator: (value)
                  {
                     if(value!.isEmpty)
                       {
                         return "Enter FirstName";
                       }
                  },
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 30, right: 20, top: 20,),
                padding: EdgeInsets.only(left: 10,),
                height: 50,
                width: 300,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black54, width: 2),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: TextFormField(
                  controller: lastName,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                      icon: Icon(Icons.person, color: Colors.black,),
                      hintText: "Last Name",
                      enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white,)
                      ),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.white)
                    ),
                  ),
                  validator: (value)
                  {
                    if(value!.isEmpty)
                    {
                      return "Enter LastName";
                    }
                  },
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 30, right: 20, top: 20,),
                padding: EdgeInsets.only(left: 10,),
                height: 50,
                width: 300,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black54, width: 2),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Row(
                  children: [
                    Icon(Icons.person, color: Colors.black,),
                    SizedBox(width: 17,),
                    Text("Gender"),
                    Radio(
                        value: genderSelect.Male,
                        groupValue: _gender,
                        onChanged: (value)
                      {
                        setState(() {
                          _gender = value!;
                        });
                      },
                    ),
                    Text("Male"),
                    Radio(
                      value: genderSelect.Female,
                      groupValue: _gender,
                      onChanged: (value)
                      {
                        setState(() {
                          _gender = value!;
                        });
                      },
                    ),
                    Text("Female"),
                  ],
                ),
              ),
              Container(
                alignment: Alignment.topRight,
                margin: EdgeInsets.only(left: 30, right: 20, top: 20,),
                padding: EdgeInsets.only(left: 10,),
                height: 220,
                width: 300,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black54, width: 2),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        SizedBox(height: 20,),
                        Icon(Icons.interests),
                        SizedBox(width: 17,),
                        Text("Hobbies"),
                        SizedBox(width: 20,),
                      ],
                    ),
                    Column(
                      children: hobbiesList.asMap().entries.map((entry) {
                        int index = entry.key;
                        String hobby = entry.value;


                        return Row(
                          children: [
                            SizedBox(width: 20),
                            Text(hobby),

                            Checkbox
                            (
                              value: hobbiesCheckedList[index],
                              onChanged: (bool? value)
                              {
                                setState(() {
                                  hobbiesCheckedList[index] = value ?? false;
                                });
                              },
                            )],
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),
              Container(
                alignment: Alignment.topLeft,
                margin: EdgeInsets.only(left: 30, right: 20, top: 20,),
                padding: EdgeInsets.only(left: 10,),
                height: 50,
                width: 300,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black54, width: 2),
                  borderRadius: BorderRadius.circular(15),
                ),
                child:
                    DropdownButton(
                      hint: Row(
                        children: [
                          Icon(Icons.location_on),
                          SizedBox(width: 17,),
                          const Text("City"),
                        ],
                      ),
                        isExpanded: true,
                        value: city,
                        items: citiesList.map((String value)
                        {
                          return DropdownMenuItem<String>(
                              value: value,
                              child: Row(
                                children: [
                                  Icon(Icons.location_on),
                                  SizedBox(width: 20,),
                                  Text(value),
                                ],
                              ));
                        }).toList(),
                        onChanged: (value)
                        {
                          FocusScope.of(context).requestFocus(FocusNode());
                          setState(() {
                            city = value!;
                          });
                        }),
              ),
              Container(
                margin: EdgeInsets.only(left: 30, right: 20, top: 20,),
                padding: EdgeInsets.only(left: 10,),
                height: 50,
                width: 300,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black54, width: 2),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: TextFormField(
                  controller: email,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                      icon: Icon(Icons.email, color: Colors.black,),
                      hintText: "Email",
                      enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white,)
                      ),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.white)
                    ),
                  ),
                  validator: (value)
                  {
                    if(value!.isEmpty)
                    {
                      return "Email";
                    }
                    else if(!RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value))
                    {
                      return "Please Enter Password with 8 character, one Uppercase, one Symbol";
                    }
                    return null;
                  },
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 30, right: 20, top: 20,),
                padding: EdgeInsets.only(left: 10,),
                height: 50,
                width: 300,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black54, width: 2),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: TextFormField(
                  controller: password,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                      icon: Icon(Icons.password, color: Colors.black,),
                      hintText: "Password",
                      enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white,)
                      ),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.white)
                    ),
                  ),
                  validator: (value)
                  {
                    if(value!.isEmpty)
                    {
                      return "Password";
                    }
                    else if(!RegExp(r"^(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$").hasMatch(value))
                      {
                        return "Please Enter Password with 8 character, one Uppercase, one Symbol";
                      }
                    return null;
                  },
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 30, right: 20, top: 20,),
                padding: EdgeInsets.only(left: 10,),
                height: 50,
                width: 300,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black54, width: 2),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: TextFormField(
                  controller: confirmPassword,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                      icon: Icon(Icons.password, color: Colors.black,),
                      hintText: "Confirm Password",
                      enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white,)
                      ),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.white)
                    ),
                  ),
                  validator: (value)
                  {
                    if(value!.isEmpty)
                    {
                      if(value != password)
                      {
                        return "Please Enter ConfirmPassword same as Password";
                      }
                      return "Please Enter Confirm Password";
                    }
                    return null;
                    },
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 30, right: 20, top: 20,),
                padding: EdgeInsets.only(left: 10,),
                height: 50,
                width: 300,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black54, width: 2),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: TextFormField(
                  controller: mobileNo,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                      icon: Icon(Icons.call, color: Colors.black,),
                      hintText: "MobileNo",
                      enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white,)
                      ),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.white)
                    ),
                  ),
                  validator: (value)
                  {
                    if(value!.isEmpty)
                    {
                      return "Enter MobileNo";
                    }
                    else if(!RegExp(r"^\d{10}$").hasMatch(value))
                    {
                      return "Please Enter Valid MobileNo";
                    }
                    return null;
                  },
                ),
              ),
              SizedBox(height: 10,),
              ElevatedButton(
                  onPressed: ()
                  {
                    String gender = _gender == genderSelect.Male ? "Male" : "Female";
                    List<String> hobbies = [];
                    for(int i=0; i<hobbiesList.length; i++)
                      {
                        if(hobbiesCheckedList[i])
                          {
                            hobbies.add(hobbiesList[i]);
                          }
                      }

                    setState(() {
                      if(_formKey.currentState!.validate())
                        {
                          var Url = Uri.parse("https://begrimed-executions.000webhostapp.com/login_form.php/insert.php");

                          http.post(Url, body:

                              {
                                "firstName": firstName.text.toString(),
                                "lastName": lastName.text.toString(),
                                "gender": gender.toString(),
                                "hobbies": hobbies.toString(),
                                "city": city.toString(),
                                "email": email.text.toString(),
                                "password": password.text.toString(),
                                "confirmPassword": confirmPassword.text.toString(),
                                "mobileNo": mobileNo.text.toString(),
                              }
                          );
                        }
                      print("firstName: ${firstName.text.toString()}");
                      print("lastName: ${lastName.text.toString()}");
                      print("gender: ${gender.toString()}");
                      print("hobbies: ${hobbies.toString()}");
                      print("city: ${city.toString()}");
                      print("email: ${email.text.toString()}");
                      print("password: ${password.text.toString()}");
                      print("confirmPassword: ${confirmPassword.text.toString()}");
                      print("mobileNo: ${mobileNo.text.toString()}");

                    });
                    Navigator.push(context, MaterialPageRoute(builder: (context) => Dashboard()));
                  },
                  child: Text("Register",),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.black54 ),
              ),

              TextButton(
                onPressed: ()
                {
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => Login()));
                },
                child: Text("Already have an Account? Login", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),)),
            ],
          ),
        ),
      ),
    );
  }
}
