import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'Dashboard.dart';
import 'package:http/http.dart' as http;

import 'Registration.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login>
{
  String email = "";
  String password = "";
  late bool newUser;
  late SharedPreferences loginData;
  var isLoading = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    check_if_already_login();
  }

  void check_if_already_login() async
  {
    loginData = await SharedPreferences.getInstance();
    newUser = (loginData.getBool('login') ?? true);
    print(newUser);

    if(newUser == false)
      {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => Dashboard()));
      }
  }

  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 150,),
              Text("Login", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),),
              Container(
                margin: EdgeInsets.only(left: 30, right: 20, top: 20,),
                padding: EdgeInsets.only(left: 10,),
                height: 50,
                width: 300,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black54, width: 2),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: TextFormField(
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                      icon: Icon(Icons.email, color: Colors.black,),
                      hintText: "Email",
                      enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white,)
                      )
                  ),
                  validator: (value)
                  {
                    email = value!;
                    if(value!.isEmpty)
                    {
                      return "Email";
                    }
                    else if(!RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value))
                    {
                      return "Please Enter Password with 8 character, one Uppercase, one Symbol";
                    }
                    return null;
                  },
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 30, right: 20, top: 20,),
                padding: EdgeInsets.only(left: 10,),
                height: 50,
                width: 300,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black54, width: 2),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: TextFormField(
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                      icon: Icon(Icons.password, color: Colors.black,),
                      hintText: "Password",
                      enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.white,)
                      )
                  ),
                  validator: (value)
                  {
                    password = value!;
                    if(value!.isEmpty)
                    {
                      return "Password";
                    }
                    else if(!RegExp(r"^(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$").hasMatch(value))
                    {
                      return "Please Enter Password with 8 character, one Uppercase, one Symbol";
                    }
                    return null;
                  },
                ),
              ),
              SizedBox(height: 20,),
              ElevatedButton(
                  onPressed: () async
                  {
                    var url = Uri.parse("https://begrimed-executions.000webhostapp.com/login_form.php/login.php");
                    var response = await http.post(url, body:
                    {
                      "email": email.toString(),
                      "password": password.toString(),
                    }
                    );

                    var data = json.decode(response.body);
                    final isValid = _formKey.currentState?.validate();
                    if(isValid!)
                      {
                        return;
                      }
                    else
                      {
                        _formKey.currentState!.save();
                        String e = email;
                        String p = password;

                        if(e!="" && p!="")
                          {
                            print("Success");
                            loginData.setBool('login', false);
                            loginData.setString('email', e);
                            loginData.setBool('login', false);
                            loginData.setString('password', p);
                          }
                      }
                    Navigator.push(context, MaterialPageRoute(builder: (context) => Dashboard()));

                  },
                  child: Text("Login"),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.black54),
              ),

              TextButton(
                  onPressed: ()
                  {
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => Registration()));
                  },
                  child: Text("Don't have an Account yet? Register", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),)),
            ],
          ),
        ),
      ),
    );
  }
}
