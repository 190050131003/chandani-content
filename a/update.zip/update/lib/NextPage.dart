import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget
{
  late String email,pass;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My App'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (choice) {
              // if (choice == 'profile') {
              //   // Handle profile option
              //   Navigator.push(
              //     context,
              //     MaterialPageRoute(builder: (context) => ProfileScreen()),
              //   );
              // }
              if (choice == 'logout')
              {
                Navigator.pop(context);
              }
            },
            itemBuilder: (BuildContext context) {
              return [
                // PopupMenuItem(
                //   value: 'profile',
                //   child: Text('Profile'),
                // ),
                PopupMenuItem(
                  value: 'logout',
                  child: Text('Logout'),
                ),
              ];
            },
          ),
        ],
      ),
      body: Center(
        child: Text('Welcome to My App'),
      ),
    );
  }
}


