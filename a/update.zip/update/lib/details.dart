import 'package:api_datainsert/view_data.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'edit.dart';

class Details extends StatefulWidget
{
  List list;
  int index;

  //index get
  Details({required this.list, required this.index});

  @override
  _DetailsState createState() => _DetailsState();

}
class _DetailsState extends State<Details>
{

  @override
  Widget build(BuildContext context)
  {

    return Scaffold(

        appBar: AppBar(title: Text('${widget.list[widget.index]['name']}'),),

        body: Container(

            width: 400,
            height: 400,
            margin: EdgeInsets.all(30),
            padding: EdgeInsets.all(20),

            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
              boxShadow: [
                BoxShadow(
                    offset: Offset(1.1, 1.1),
                    blurRadius: 20.0,
                    color: Colors.grey
                ),
              ],
            ),

            child: Column(
                children: [


                  Text(
                    widget.list[widget.index]['name'],
                    style: TextStyle(fontSize: 20.0),
                  ),

                  Text(
                    widget.list[widget.index]['email'],
                    style: TextStyle(fontSize: 20.0),
                  ),


                  MaterialButton(
                    child: Text("Edit"),
                    color: Colors.cyan,

                    onPressed: ()=>Navigator.of(context).push
                      (
                      MaterialPageRoute(builder: (BuildContext context)=> Edit(list:widget.list,index:widget.index)),
                    ),
                  ),

                  MaterialButton(
                      child: Text("Delete"),
                      color: Colors.cyan,
                      onPressed: ()
                      {
                        confirm();
                      }
                  )
                ]
            )
        )
    );
  }

  void confirm()
  {

    var url = Uri.parse("https://begrimed-executions.000webhostapp.com/API/databaseDelete.php");
    http.post(url ,body:
    {
      'id':widget.list[widget.index]['id'],

    });
    Navigator.of(context).push
      (
        MaterialPageRoute(builder: (BuildContext context)=> MyView()));


  }

}