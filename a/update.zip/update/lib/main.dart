import 'package:api_datainsert/login.dart';
import 'package:flutter/material.dart';


void main()
{
  runApp(MaterialApp(
      home: Login(),
      debugShowCheckedModeBanner: false));
}