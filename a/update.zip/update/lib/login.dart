import 'dart:convert';
import 'dart:core';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;


class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login>
{
  final _formKey = GlobalKey<FormState>();
  late String pnumber,pass;
  late SharedPreferences logindata;

  late bool newuser;
  var isLoading = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    check_if_already_login();
  }
  void check_if_already_login() async
  {
    logindata = await SharedPreferences.getInstance();
    newuser = (logindata.getBool('login') ?? true);
    print(newuser);
    if (newuser == false) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => Dashboard()));
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Form(
        key: _formKey,
        child: Column(

          children: [
            SizedBox(height: MediaQuery.of(context).size.width * 0.2),

            Container(
              margin: EdgeInsets.only(left: 25),
              width: 350,
              child: Column(
                children: [
                  SizedBox(height: 100,),

                  Text("Welcome Back",style: TextStyle(color: CupertinoColors.white,fontSize: 25,fontWeight: FontWeight.bold),),

                  SizedBox(height: 25,),

                  TextFormField(
                    decoration: InputDecoration(

                      prefixIcon: Icon(Icons.call),
                      labelText: "Phone",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20), // Reduced the value for a more reasonable radius
                      ),
                      filled: true, // Set filled to true
                      fillColor: Colors.white, // Set fillColor to white
                    ),
                    keyboardType: TextInputType.number,
                    onFieldSubmitted: (value) {

                    },
                    validator: (value) {
                      pnumber = value!;
                      if (value == null || value.isEmpty)
                      {
                        return 'Please enter a phone number';
                      }

                      return null;
                    },
                  ),

                  SizedBox(height: 20,),

                  TextFormField(
                    decoration: InputDecoration(

                      prefixIcon: Icon(Icons.lock_outline),
                      labelText: "Password",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20), // Reduced the value for a more reasonable radius
                      ),
                      filled: true, // Set filled to true
                      fillColor: Colors.white, // Set fillColor to white
                    ),
                    keyboardType: TextInputType.number,
                    obscureText: true,
                    onFieldSubmitted: (value) {

                    },
                    validator: (value) {
                      pass = value!;
                      if (value == null || value.isEmpty)
                      {
                        return 'Please enter a Password';
                      }

                      return null;
                    },
                  ),

                  SizedBox(height: 20,),

                  GestureDetector(
                    onTap: onTapText,
                    child: Text('Forgot Your Password?', style: TextStyle(decoration: TextDecoration.underline,color: CupertinoColors.white),),
                  ),

                  SizedBox(height: 20,),

                  ElevatedButton(
                    style: ButtonStyle(
                      minimumSize: MaterialStateProperty.all(Size(350, 50)),
                      elevation: MaterialStateProperty.all<double>(4.0), // Adjust the elevation as needed
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50.0), // Adjust the border radius as needed
                        ),
                      ),
                    ),

                    onPressed: ()
                    async {
                      _Login();
                      var url = Uri.parse("https://roasting-conflict.000webhostapp.com/API/login.php");

                      var response = await http.post(url, body:
                      {

                        "Phone": pnumber.toString(),
                        "Password": pass.toString(),


                      });
                      var data = json.decode(response.body);
                      if(data==0)
                      {
                        print("fail2");
                      }
                      else
                      {
                        print("success2");

                      }

                    },
                    child: Text('Login'),
                  ),

                  SizedBox(height: 20,),

                  //"Don't have an account yer? Register
                  GestureDetector(
                    onTap: onTap,
                    child: Text("Don't have an account yer? Register", style: TextStyle(color: CupertinoColors.white),),
                  ),


                ],
              ),
            ),

          ],
        ),
      ),
    );
  }

  void onTapText()
  {
    Fluttertoast.showToast
      (
        msg: "Working on it",
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.red,
        textColor: Colors.yellow
    );
  }



  void onTap()
  {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => Register()));
  }

  void _Login()
  {
    final isValid  = _formKey.currentState?.validate();
    if(!isValid!)
    {
      return ;
    }
    else
    {
      _formKey.currentState?.save();
      String phonenumber = pnumber;
      String password = pass;
      if(phonenumber != '' && password !='')
      {
        print('success');
        logindata.setBool('login', false);
        logindata.setString('phnenumber', phonenumber);
        Navigator.push(context, MaterialPageRoute(builder: (context) => Dashboard()));


      }
    }
  }
}