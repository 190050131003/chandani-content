import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:module3_numbers/two_numbers.dart';

void main()
{
  runApp(MyApp2());
}

class MyApp2 extends StatelessWidget
{
  @override
  Widget build(BuildContext context)
  {
    return MaterialApp(

      home: MyApp(),
      debugShowCheckedModeBanner: false,
    );
  }

}