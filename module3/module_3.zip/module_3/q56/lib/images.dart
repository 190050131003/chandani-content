import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class images extends StatefulWidget
{
  @override
  ImageState createState() => ImageState();

}

class ImageState extends State<images>
{
  bool isChecked = false;

  @override
  Widget build(BuildContext context)
  {
    return Scaffold(

      body: Center(

        child: Container(

          child: Column(

            children: [

              Column(

                children: [

                  SizedBox(height: 200),

                  Image.network("https://begrimed-executions.000webhostapp.com/images/I1.jpeg", width: 50, height: 50),

                  SizedBox(height: 40),

                  Row(

                    children: [

                      SizedBox(width: 20),

                      Image.network("https://begrimed-executions.000webhostapp.com/images/I2.jpeg", width: 50, height: 50),

                      SizedBox(width: 70,),

                      Text("TextView", style: TextStyle(fontSize: 20),),

                      SizedBox(width: 70),

                      Image.network("https://begrimed-executions.000webhostapp.com/images/I3.jpeg", width: 50, height: 50),
                    ],
                  ),

                  Column(

                    children: [

                      SizedBox(height: 50),

                      Image.network("https://begrimed-executions.000webhostapp.com/images/I4.jpeg", width: 50, height: 50),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

}